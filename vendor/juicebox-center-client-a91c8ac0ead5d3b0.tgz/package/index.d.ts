import { Address, Hex } from 'viem';

/** Browser-safe primitives shared by the existing signed-request client and server. */
type BotScope = "read" | "plan" | "relay";
declare function isCanonicalGrantScopes(scopes: unknown): scopes is BotScope[];

declare const REST_AUTH_HEADERS: {
    readonly account: "X-Juicebox-Account";
    readonly signer: "X-Juicebox-Signer";
    readonly grant: "X-Juicebox-Grant";
    readonly issuedAt: "X-Juicebox-Issued-At";
    readonly expiresAt: "X-Juicebox-Expires-At";
    readonly nonce: "X-Juicebox-Nonce";
    readonly signature: "X-Juicebox-Signature";
    readonly idempotencyKey: "Idempotency-Key";
};
type RequestClaims = {
    accountId: string;
    signer: Address;
    grantId: string;
    method: string;
    requestTarget: string;
    contentType: string;
    bodyHash: Hex;
    issuedAt: number;
    expiresAt: number;
    nonce: Hex;
    idempotencyKey: string;
};
type BotProof = {
    accountId: string;
    botAddress: Address;
    scopes: BotScope[];
    expiresAt: number;
    label: string;
    ownerRequestNonce: Hex;
};
declare function accountIdFor(owner: Address, authorityChainId: number): string;
declare function buildRequestTypedData(audience: string, claims: RequestClaims): {
    domain: {
        readonly name: "Juicebox Center REST";
        readonly version: "1";
        readonly chainId: number;
        readonly salt: `0x${string}`;
    };
    types: {
        readonly CenterRequest: readonly [{
            readonly name: "audience";
            readonly type: "string";
        }, {
            readonly name: "accountId";
            readonly type: "string";
        }, {
            readonly name: "signer";
            readonly type: "address";
        }, {
            readonly name: "grantId";
            readonly type: "string";
        }, {
            readonly name: "method";
            readonly type: "string";
        }, {
            readonly name: "requestTarget";
            readonly type: "string";
        }, {
            readonly name: "contentType";
            readonly type: "string";
        }, {
            readonly name: "bodyHash";
            readonly type: "bytes32";
        }, {
            readonly name: "issuedAt";
            readonly type: "uint64";
        }, {
            readonly name: "expiresAt";
            readonly type: "uint64";
        }, {
            readonly name: "nonce";
            readonly type: "bytes32";
        }, {
            readonly name: "idempotencyKey";
            readonly type: "string";
        }];
    };
    primaryType: "CenterRequest";
    message: {
        audience: string;
        issuedAt: bigint;
        expiresAt: bigint;
        accountId: string;
        signer: Address;
        grantId: string;
        method: string;
        requestTarget: string;
        contentType: string;
        bodyHash: Hex;
        nonce: Hex;
        idempotencyKey: string;
    };
};
declare function buildBotProofTypedData(audience: string, proof: BotProof): {
    domain: {
        readonly name: "Juicebox Center REST";
        readonly version: "1";
        readonly chainId: number;
        readonly salt: `0x${string}`;
    };
    types: {
        readonly CenterBotProof: readonly [{
            readonly name: "audience";
            readonly type: "string";
        }, {
            readonly name: "accountId";
            readonly type: "string";
        }, {
            readonly name: "botAddress";
            readonly type: "address";
        }, {
            readonly name: "scopes";
            readonly type: "string[]";
        }, {
            readonly name: "expiresAt";
            readonly type: "uint64";
        }, {
            readonly name: "label";
            readonly type: "string";
        }, {
            readonly name: "ownerRequestNonce";
            readonly type: "bytes32";
        }];
    };
    primaryType: "CenterBotProof";
    message: {
        audience: string;
        expiresAt: bigint;
        accountId: string;
        botAddress: Address;
        scopes: BotScope[];
        label: string;
        ownerRequestNonce: Hex;
    };
};
declare function newRequestNonce(): Hex;

/** Identifies one immutable effect, including the exact serialized transaction signature. */
type TransactionApprovalBinding = {
    accountId: string;
    principalId: string;
    planId: string;
    commitment: Hex;
    stepIndex: number;
    transactionHash: Hex;
};
type TransactionApprovalClaims = TransactionApprovalBinding & {
    issuedAt: number;
    expiresAt: number;
    nonce: Hex;
};
type TransactionApproval = TransactionApprovalClaims & {
    signature: Hex;
};
type SponsorshipApprovalBinding = {
    accountId: string;
    principalId: string;
    sponsorshipId: string;
    commitment: Hex;
    submissionHash: Hex;
};
type SponsorshipApprovalClaims = SponsorshipApprovalBinding & {
    issuedAt: number;
    expiresAt: number;
    nonce: Hex;
};
type SponsorshipApproval = SponsorshipApprovalClaims & {
    signature: Hex;
};
/** Browser-safe owner-wallet signing document; use a fresh cryptographically random nonce. */
declare function buildTransactionApprovalTypedData(audience: string, input: TransactionApprovalClaims): {
    domain: {
        name: string;
        version: string;
        chainId: number;
        salt: `0x${string}`;
    };
    types: {
        readonly CenterTransactionApproval: readonly [{
            readonly name: "audience";
            readonly type: "string";
        }, {
            readonly name: "accountId";
            readonly type: "string";
        }, {
            readonly name: "principalId";
            readonly type: "string";
        }, {
            readonly name: "planId";
            readonly type: "string";
        }, {
            readonly name: "commitment";
            readonly type: "bytes32";
        }, {
            readonly name: "stepIndex";
            readonly type: "uint32";
        }, {
            readonly name: "transactionHash";
            readonly type: "bytes32";
        }, {
            readonly name: "issuedAt";
            readonly type: "uint64";
        }, {
            readonly name: "expiresAt";
            readonly type: "uint64";
        }, {
            readonly name: "nonce";
            readonly type: "bytes32";
        }];
    };
    primaryType: "CenterTransactionApproval";
    message: {
        audience: string;
        issuedAt: bigint;
        expiresAt: bigint;
        accountId: string;
        principalId: string;
        planId: string;
        commitment: Hex;
        stepIndex: number;
        transactionHash: Hex;
        nonce: Hex;
    };
};
/** Approves publishing exact signed forward requests, independently of direct transaction relay. */
declare function buildSponsorshipApprovalTypedData(audience: string, input: SponsorshipApprovalClaims): {
    domain: {
        name: string;
        version: string;
        chainId: number;
        salt: `0x${string}`;
    };
    types: {
        readonly CenterSponsorshipApproval: readonly [{
            readonly name: "audience";
            readonly type: "string";
        }, {
            readonly name: "accountId";
            readonly type: "string";
        }, {
            readonly name: "principalId";
            readonly type: "string";
        }, {
            readonly name: "sponsorshipId";
            readonly type: "string";
        }, {
            readonly name: "commitment";
            readonly type: "bytes32";
        }, {
            readonly name: "submissionHash";
            readonly type: "bytes32";
        }, {
            readonly name: "issuedAt";
            readonly type: "uint64";
        }, {
            readonly name: "expiresAt";
            readonly type: "uint64";
        }, {
            readonly name: "nonce";
            readonly type: "bytes32";
        }];
    };
    primaryType: "CenterSponsorshipApproval";
    message: {
        audience: string;
        issuedAt: bigint;
        expiresAt: bigint;
        nonce: `0x${string}`;
        accountId: string;
        principalId: string;
        sponsorshipId: string;
        commitment: Hex;
        submissionHash: Hex;
    };
};
/** Matches the server's canonical SHA-256 publication identity; order is significant. */
declare function sponsorshipSubmissionHash(commitment: Hex, signatures: readonly Hex[]): Hex;

interface RestBlockEvidence {
    chainId: number;
    blockNumber: string;
    blockHash: Hex;
    timestamp: string;
    source: "onchain";
}
interface RestCall {
    chainId: number;
    to: Address;
    data: Hex;
    value: string;
    label: string;
    dependsOn: number[];
    decoded: unknown;
}
/** A reviewable plan contains no key material and conveys no signing authority. */
interface RestPlanDraft {
    operation: string;
    account: Address;
    project?: {
        chainId: number;
        projectId: string;
        version?: 6;
    };
    calls: RestCall[];
    evidence: RestBlockEvidence[];
    summary: unknown;
    warnings: string[];
}
interface RestActor {
    accountId: string;
    /** Bot grant ID, or an owner principal distinguished from every bot. */
    principalId: string;
}

type StepState = "waiting" | "reserved" | "submitted" | "unknown" | "confirming" | "confirmed" | "reverted" | "reorged";
interface SemanticResult {
    /** Unknown modeled results block dependent steps; unmodeled calls are explicit. */
    status: "verified" | "failed" | "unknown" | "unmodeled";
    details?: unknown;
}
interface StoredReceipt {
    transactionHash: Hex;
    blockHash: Hex;
    blockNumber: string;
    status: "success" | "reverted";
    confirmations: number;
    canonical: boolean;
    observedAt: number;
    logs: unknown[];
    /** Persistent records omit logs after semantic verification; these identify the full RPC log list. */
    logCount?: number;
    logsHash?: Hex;
    logsStored?: boolean;
}
interface SignedAttempt {
    hash: Hex;
    rawTransaction: Hex;
    sender: Address;
    chainId: number;
    nonce: string;
    type: "legacy" | "eip2930" | "eip1559";
    gas: string;
    maximumFeePerGas: string;
    /** Native value + gas limit * fee cap; excludes additional rollup data/operator charges. */
    maximumCost: string;
    reservedAt: number;
    leaseToken: string;
    leaseUntil: number;
    dispatchCount: number;
    broadcastAt?: number;
    lastError?: {
        code: string;
        message: string;
    };
}
interface StoredStep {
    index: number;
    state: StepState;
    attempt?: SignedAttempt;
    /** A forwarded execution is not an owner-signed EOA transaction attempt. */
    externalExecution?: ExternalExecution;
    receipt?: StoredReceipt;
    semantic?: SemanticResult;
}
interface ExternalExecution {
    transport: "relayr" | "erc4337";
    bindingId: string;
    chainId: number;
    transactionHash?: Hex;
}
interface StoredPlan {
    id: string;
    actor: RestActor;
    draft: RestPlanDraft;
    commitment: Hex;
    createdAt: number;
    expiresAt: number;
    revision: number;
    /** Verified owner binding for a contract wallet. It never grants EOA relay authority. */
    smartAccount?: {
        bindingId: Hex;
        stateHash: Hex;
        chainId: number;
        address: Address;
        manifestRevision: Hex;
    };
    steps: StoredStep[];
}

/** Standard unpacked EntryPoint v0.7 RPC representation. No v0.8/7702 extensions. */
interface UserOperationV07 {
    sender: Address;
    nonce: Hex;
    factory?: Address;
    factoryData?: Hex;
    callData: Hex;
    callGasLimit: Hex;
    verificationGasLimit: Hex;
    preVerificationGas: Hex;
    maxFeePerGas: Hex;
    maxPriorityFeePerGas: Hex;
    paymaster?: Address;
    paymasterVerificationGasLimit?: Hex;
    paymasterPostOpGasLimit?: Hex;
    paymasterData?: Hex;
    signature: Hex;
}
interface UserOperationObservation {
    state: "pending" | "unknown" | "confirming" | "confirmed" | "reverted";
    operationHash: Hex;
    transactionHash?: Hex;
    receipt?: StoredReceipt;
    /** Logs are restricted to this operation's execution interval in the EntryPoint bundle. */
    scopedLogs?: readonly unknown[];
    semantic?: SemanticResult;
    reason?: string;
}

interface Safe7579OwnerSigningInput {
    operation: UserOperationV07;
    chainId: number;
    safe7579: Address;
    entryPoint: Address;
    validAfter: string;
    validUntil: string;
}
declare function safe7579OwnerSigningPayload(input: Safe7579OwnerSigningInput): {
    scheme: "eip712-safe7579-owner";
    digest: `0x${string}`;
    typedData: {
        domain: {
            chainId: number;
            verifyingContract: `0x${string}`;
        };
        message: {
            nonce: string;
            verificationGasLimit: string;
            callGasLimit: string;
            preVerificationGas: string;
            maxPriorityFeePerGas: string;
            maxFeePerGas: string;
            validAfter: string;
            validUntil: string;
            safe: `0x${string}`;
            initCode: `0x${string}`;
            callData: `0x${string}`;
            paymasterAndData: `0x${string}`;
            entryPoint: `0x${string}`;
        };
        types: {
            readonly EIP712Domain: readonly [{
                readonly name: "chainId";
                readonly type: "uint256";
            }, {
                readonly name: "verifyingContract";
                readonly type: "address";
            }];
            readonly SafeOp: readonly [{
                readonly name: "safe";
                readonly type: "address";
            }, {
                readonly name: "nonce";
                readonly type: "uint256";
            }, {
                readonly name: "initCode";
                readonly type: "bytes";
            }, {
                readonly name: "callData";
                readonly type: "bytes";
            }, {
                readonly name: "verificationGasLimit";
                readonly type: "uint128";
            }, {
                readonly name: "callGasLimit";
                readonly type: "uint128";
            }, {
                readonly name: "preVerificationGas";
                readonly type: "uint256";
            }, {
                readonly name: "maxPriorityFeePerGas";
                readonly type: "uint128";
            }, {
                readonly name: "maxFeePerGas";
                readonly type: "uint128";
            }, {
                readonly name: "paymasterAndData";
                readonly type: "bytes";
            }, {
                readonly name: "validAfter";
                readonly type: "uint48";
            }, {
                readonly name: "validUntil";
                readonly type: "uint48";
            }, {
                readonly name: "entryPoint";
                readonly type: "address";
            }];
        };
        primaryType: "SafeOp";
    };
    validAfter: string;
    validUntil: string;
};
interface LegacySessionSigningInput {
    operation: UserOperationV07;
    chainId: number;
    entryPoint: Address;
    smartSessions: Address;
    permissionId: Hex;
}
/** ff742c54 OwnableValidator.validateSignatureWithData prefixes the 32-byte UserOp hash. */
declare function legacySessionSigningPayload(input: LegacySessionSigningInput): {
    scheme: "eip191-legacy-ownable-user-operation";
    operationHash: `0x${string}`;
    digest: `0x${string}`;
    message: {
        raw: `0x${string}`;
    };
    permissionId: `0x${string}`;
    /** The prefix is an envelope selector, not an additional field in the signed UserOp hash. */
    signaturePrefix: `0x${string}`;
};

/** The legacy Safe owner ERC-1271 selector hashes this preimage once, just like checkSignatures. */
declare function safe7579PasskeyOwnerSigningPayload(input: Safe7579OwnerSigningInput): {
    signedData: `0x${string}`;
    scheme: "eip712-safe7579-owner";
    digest: `0x${string}`;
    typedData: {
        domain: {
            chainId: number;
            verifyingContract: `0x${string}`;
        };
        message: {
            nonce: string;
            verificationGasLimit: string;
            callGasLimit: string;
            preVerificationGas: string;
            maxPriorityFeePerGas: string;
            maxFeePerGas: string;
            validAfter: string;
            validUntil: string;
            safe: `0x${string}`;
            initCode: `0x${string}`;
            callData: `0x${string}`;
            paymasterAndData: `0x${string}`;
            entryPoint: `0x${string}`;
        };
        types: {
            readonly EIP712Domain: readonly [{
                readonly name: "chainId";
                readonly type: "uint256";
            }, {
                readonly name: "verifyingContract";
                readonly type: "address";
            }];
            readonly SafeOp: readonly [{
                readonly name: "safe";
                readonly type: "address";
            }, {
                readonly name: "nonce";
                readonly type: "uint256";
            }, {
                readonly name: "initCode";
                readonly type: "bytes";
            }, {
                readonly name: "callData";
                readonly type: "bytes";
            }, {
                readonly name: "verificationGasLimit";
                readonly type: "uint128";
            }, {
                readonly name: "callGasLimit";
                readonly type: "uint128";
            }, {
                readonly name: "preVerificationGas";
                readonly type: "uint256";
            }, {
                readonly name: "maxPriorityFeePerGas";
                readonly type: "uint128";
            }, {
                readonly name: "maxFeePerGas";
                readonly type: "uint128";
            }, {
                readonly name: "paymasterAndData";
                readonly type: "bytes";
            }, {
                readonly name: "validAfter";
                readonly type: "uint48";
            }, {
                readonly name: "validUntil";
                readonly type: "uint48";
            }, {
                readonly name: "entryPoint";
                readonly type: "address";
            }];
        };
        primaryType: "SafeOp";
    };
    validAfter: string;
    validUntil: string;
};

type Profile = {
    displayName: string;
    bio: string;
    avatarUri: string | null;
};
type Account = {
    id: string;
    ownerAddress: Address;
    authorityChainId: number;
    profile: Profile;
    createdAt: number;
    updatedAt: number;
};
type BotGrant = {
    id: string;
    accountId: string;
    botAddress: Address;
    scopes: BotScope[];
    label: string;
    createdAt: number;
    expiresAt: number;
    revokedAt: number | null;
};

interface ContractPin {
    address: Address;
    runtimeCodeHash: Hex;
    source: {
        repository: string;
        commit?: string;
        contentSha256?: string;
        artifactSha256: string;
    };
}
/** Explicit opt-in; the legacy EOA profile remains the default for existing manifests. */
interface PasskeyOwnerProfile {
    version: "center-passkey-v1";
    signerFactory: ContractPin;
    signerSingleton: ContractPin;
    /** Reviewed Solidity FCL verifier only. No implicit chain precompile assumption. */
    p256Verifier: ContractPin;
}
interface PasskeyOwnerState {
    version: "center-passkey-v1";
    signer: {
        address: Address;
        kind: "contract";
        x: Hex;
        y: Hex;
        verifiers: Hex;
        runtimeCodeHash: Hex;
    };
    recoveryOwner: {
        address: Address;
        kind: "ecdsa";
    };
}
interface PasskeyCreationProfile {
    version: "center-passkey-bootstrap-v1";
    multiSend: ContractPin;
}
/** Server-owned reviewed deployment configuration. Never accepted from HTTP request bodies. */
interface SmartAccountManifest {
    id: string;
    mode: "ownership-only" | "execution-candidate";
    chainId: number;
    revision: Hex;
    safeVersion: "1.4.1";
    proxyRuntimeCodeHash: Hex;
    singleton: ContractPin;
    factory: ContractPin;
    safe7579: ContractPin;
    launchpad: ContractPin;
    /** Omitted for an ownership-binding-only manifest whose EntryPoint source identity is unproved. */
    entryPoint?: ContractPin & {
        version: "0.7";
    };
    smartSessions: ContractPin & {
        generation: "legacy-validator" | "emissary";
    };
    policies: readonly ContractPin[];
    /** Pin the adapter that enumerates validators/executors/hooks/fallbacks/attesters. */
    moduleInspectorId: string;
    ownerProfile?: PasskeyOwnerProfile;
    creationProfile?: PasskeyCreationProfile;
}
interface ModuleStateEvidence {
    /** Hash of the complete module/validator/hook/fallback/registry/attester configuration. */
    stateHash: Hex;
    complete: true;
    arbitrarySigningDisabled: true;
    wildcardExecutionDisabled: true;
    details: unknown;
}
interface SmartAccountState {
    chainId: number;
    address: Address;
    manifestId: string;
    manifestRevision: Hex;
    owners: Address[];
    threshold: number;
    safeNonce: string;
    stateHash: Hex;
    evidence: RestBlockEvidence;
    codeHashes: {
        address: Address;
        runtimeCodeHash: Hex;
    }[];
    modules: ModuleStateEvidence | null;
    moduleConfigurationVerified: boolean;
    executionVerified: boolean;
    ownerProfile?: PasskeyOwnerState;
}
interface SmartAccountBinding {
    id: Hex;
    ownerAccountId: string;
    ownerAddress: Address;
    wallet: {
        chainId: number;
        address: Address;
    };
    manifestId: string;
    authorization: {
        digest: Hex;
        nonce: Hex;
        expiresAt: number;
        method: "safe-current-owner-threshold" | "safe-current-owner-threshold-and-api-grant" | "safe-passkey-owner-threshold-and-api-grant";
        setup?: {
            manifestRevision: Hex;
            initializerHash: Hex;
            issuedAt: number;
            grantId: string;
            botAddress: Address;
            scopes: BotScope[];
            grantExpiresAt: number;
            label: string;
        };
    };
    state: SmartAccountState;
}
interface Allocation {
    id: string;
    chainId: number;
    asset: Address;
    limit: string;
}
interface AllocationGroup {
    id: string;
    total: string;
    allocations: Allocation[];
}
type SessionAction = {
    kind: "v6-project-uri";
    controller: Address;
    projectId: string;
} | {
    kind: "erc20-transfer";
    allocationId: string;
    beneficiary: Address;
    perCallLimit: string;
    totalLimit: string;
} | {
    kind: "v6-pay";
    allocationId: string;
    terminal: Address;
    projectId: string;
    beneficiary: Address;
    perCallLimit: string;
    totalLimit: string;
    /** Exact minimum; the bot cannot replace it with zero. */
    minReturnedTokens: string;
};
interface SessionPolicyInput {
    bindingId: Hex;
    grantId: string;
    generation: string;
    nonce: Hex;
    validAfter: number;
    durationDays: 7 | 30;
    maximumCalls: string;
    gasBudget?: {
        paymaster: Address;
        maxGasPerOperation: string;
        maxFeePerGas: string;
        maxPriorityFeePerGas: string;
        totalGasLimit: string;
        totalSponsoredCostLimit: string;
        maxPaymasterDataLength: number;
    };
    allocations: AllocationGroup[];
    actions: SessionAction[];
}

type CreationInput = {
    manifest: SmartAccountManifest;
    owners: readonly Address[];
    threshold: number;
    saltNonce: string;
};
/** Pure preparation only. The owner signs and funds the factory transaction in their wallet. */
declare function prepareSafe7579Creation(input: CreationInput): {
    chainId: number;
    manifestId: string;
    manifestRevision: `0x${string}`;
    address: `0x${string}`;
    owners: `0x${string}`[];
    threshold: number;
    saltNonce: string;
    initializer: `0x${string}`;
    initializerHash: `0x${string}`;
    transaction: {
        to: `0x${string}`;
        value: "0";
        data: `0x${string}`;
    };
    initialAuthority: {
        validator: `0x${string}`;
        enabledSessions: number;
        executors: never[];
        hooks: never[];
        fallbacks: never[];
        registryEnforced: false;
    };
};

interface LegacyPolicyData {
    policy: Address;
    initData: Hex;
}
interface LegacyActionData {
    actionTargetSelector: Hex;
    actionTarget: Address;
    actionPolicies: LegacyPolicyData[];
}
/** Exact f24dddf Session tuple; this type is not accepted as caller-supplied policy authority. */
interface LegacySession {
    sessionValidator: Address;
    sessionValidatorInitData: Hex;
    salt: Hex;
    userOpPolicies: LegacyPolicyData[];
    erc7739Policies: {
        allowedERC7739Content: [];
        erc1271Policies: [];
    };
    actions: LegacyActionData[];
    permitERC4337Paymaster: boolean;
}
interface CompiledPolicyConfiguration {
    kind: "time-frame" | "universal-action" | "value-limit" | "usage-limit" | "gas-budget";
    policy: ContractPin;
    configId: Hex;
    scope: "user-operation" | "action";
    actionId?: Hex;
    initData: Hex;
    decoded: unknown;
}
interface CompiledSession {
    schemaVersion: 1;
    stack: "legacy-f24dddf-safe7579-f22a194";
    ownerAccountId: string;
    bindingId: Hex;
    grantId: string;
    sessionKey: Address;
    chainId: number;
    wallet: Address;
    generation: string;
    nonce: Hex;
    validAfter: number;
    validUntil: number;
    salt: Hex;
    policyHash: Hex;
    compiledHash: Hex;
    permissionId: Hex;
    manifestRevision: Hex;
    /** Owner review includes this nonce; revocation must advance it and remove the session. */
    activationEnableNonce: string;
    reviewedPolicy: unknown;
    smartSessions: ContractPin;
    sessionValidator: ContractPin;
    session: LegacySession;
    configurations: CompiledPolicyConfiguration[];
}
interface InstalledSessionObservation {
    permissionId: Hex;
    compiledHash: Hex;
    account: Address;
    chainId: number;
    enabled: boolean;
    enableNonce: string;
    configurationHash: Hex;
    evidence: RestBlockEvidence;
    counters: {
        policy: Address;
        configId: Hex;
        name: string;
        used: string;
        limit: string;
    }[];
    /** Complete canonical administration trace evidence attached by the lifecycle service at the same block. */
    administration?: {
        epoch: string;
        hash: Hex;
        lastInitialization?: {
            epoch: string;
            permissionIds: Hex[];
        };
    };
}

type SessionState = "prepared" | "installing" | "active" | "revoking" | "revoked" | "expired" | "stale";
interface SessionAllocation {
    id: string;
    chainId: number;
    asset: Address;
    limit: string;
    assetReviewId: string;
}
interface SessionAllocationGroup {
    id: string;
    assetIdentity: string;
    decimals: number;
    total: string;
    allocations: SessionAllocation[];
}
/** Verified server-side consent for this exact owner-approved setup/revocation plan. */
interface SessionOwnerApproval {
    kind: "activation" | "revocation";
    accountId: string;
    sessionId: string;
    policyHash: Hex;
    compiledHash: Hex;
    planId: string;
    planCommitment: Hex;
    digest: Hex;
    issuedAt: number;
    expiresAt: number;
}
interface SessionCanonicalObservation {
    /** Comes from the trusted installed-policy verifier, never an HTTP proof body. */
    installed: InstalledSessionObservation;
    observedAt: number;
    /** True only after the host independently verifies chain finality for this exact block. */
    finalized: boolean;
    proofHash: Hex;
}
interface SessionInvalidation {
    reason: "reorg" | "configuration-changed" | "counter-reset" | "grant-inactive" | "binding-unlinked" | "verification-unavailable";
    priorProofHash: Hex | null;
    observedAt: number;
}
interface StoredSession {
    id: string;
    actor: RestActor;
    compiled: CompiledSession;
    /** Complete canonical administration baseline from the verified preparation block. Immutable. */
    preparedAdministration: {
        epoch: string;
        hash: Hex;
    };
    /** Full normalized approved grouping, including sibling-chain allocations; no shared balance is inferred. */
    allocationGroups: SessionAllocationGroup[];
    allocationManifestHash: Hex;
    createdAt: number;
    updatedAt: number;
    revision: number;
    state: SessionState;
    activation?: SessionOwnerApproval;
    revocation?: SessionOwnerApproval;
    supersededApprovals?: {
        approval: SessionOwnerApproval;
        supersededAt: number;
    }[];
    observation?: SessionCanonicalObservation;
    invalidation?: SessionInvalidation;
    /** Finalized retirement only; identity tombstones remain permanent. */
    reservationsReleased: boolean;
}
interface UserOperationSessionBinding {
    id: string;
    policyHash: Hex;
    compiledHash: Hex;
    generation: string;
    grantId: string;
    permissionId: Hex;
    sessionKey: Address;
    observationHash: Hex;
}
interface SessionQuota {
    sessionId: string;
    state: SessionState;
    allocationManifestHash: Hex;
    approvedGroups: SessionAllocationGroup[];
    localAllocations: SessionAllocation[];
    counters: InstalledSessionObservation["counters"] | null;
    observation: SessionCanonicalObservation | null;
    reservationsReleased: boolean;
    executionAuthority: false;
    balanceSource: "onchain-only";
    atomicAcrossChains: false;
}

interface UserOperationRecord {
    id: string;
    actor: RestActor;
    planId: string;
    planCommitment: Hex;
    stepIndexes: number[];
    chainId: number;
    entryPoint: Address;
    sender: Address;
    operation: UserOperationV07;
    operationHash: Hex;
    preparationKey: string;
    inputHash: Hex;
    commitment: Hex;
    accountBindingId: Hex;
    accountStateHash: Hex;
    session?: UserOperationSessionBinding;
    gasPolicyId: string;
    providerId: string;
    createdAt: number;
    expiresAt: number;
    revision: number;
    state: 'prepared' | 'submitting' | 'submission_unknown' | UserOperationObservation['state'];
    submission?: {
        key: string;
        commitment: Hex;
        operation: UserOperationV07;
        startedAt: number;
        sessionObservationHash?: Hex;
    };
    observation?: UserOperationObservation;
}

interface WalletProvider {
    request(input: {
        method: string;
        params?: unknown[];
    }): Promise<unknown>;
}
interface WalletTypedData {
    domain: Record<string, unknown>;
    types: Record<string, readonly {
        name: string;
        type: string;
    }[]>;
    primaryType: string;
    message: Record<string, unknown>;
}
interface SmartAccountCapabilities {
    deployments: {
        manifestId: string;
        chainId: number;
        mode: string;
        revision: Hex;
        moduleGeneration: string;
        moduleInspectionConfigured: boolean;
        entryPointSourceVerified: boolean;
        manifest?: SmartAccountManifest;
    }[];
    requirements: string[];
    walletCreation: boolean;
    userOperationPreparation?: boolean;
    userOperationSimulation?: boolean;
    userOperationRelay?: boolean;
    sessionDurationsDays: number[];
}
interface BindingRequest {
    manifestId: string;
    address: Address;
    nonce: Hex;
    expiresAt: number;
}
interface BindingChallenge {
    state: SmartAccountState;
    typedData: WalletTypedData;
    digest: Hex;
}
interface WalletCreationRequest {
    manifestId: string;
    owners: Address[];
    threshold: number;
    saltNonce: string;
}
type WalletCreationPreparation = ReturnType<typeof prepareSafe7579Creation> & {
    deploymentConfirmed: false;
    evidence: unknown;
};
type OwnerSigningPayload = ReturnType<typeof safe7579OwnerSigningPayload>;
/** Contract owners sign this exact SafeOp digest using a WebAuthn assertion; its dynamic
 * envelope is distinct from the EOA-only ownerOperationSignature packing helper below.
 * The profile field describes the prepared encoding, not deployment or provider readiness.
 */
type PasskeyOwnerSigningPayload = ReturnType<typeof safe7579PasskeyOwnerSigningPayload> & {
    ownerProfile: "center-passkey-v1";
};
type SessionSigningPayload = ReturnType<typeof legacySessionSigningPayload>;
type SmartWalletPlan = Pick<StoredPlan, "id" | "draft" | "commitment" | "createdAt" | "expiresAt" | "revision" | "smartAccount"> & {
    steps: Pick<StoredPlan["steps"][number], "index" | "state">[];
    status?: string;
};
/** The HTTP view deliberately excludes actor, sender (available on operation), and signed bytes. */
type PreparedUserOperation = Omit<UserOperationRecord, "actor" | "sender" | "submission" | "preparationKey" | "inputHash"> & {
    signing: OwnerSigningPayload | PasskeyOwnerSigningPayload | SessionSigningPayload;
    submission?: {
        commitment: Hex;
        startedAt: number;
    };
};
declare function smartRequestKey(): string;
/** Public-key material, policies and signatures only. This facade never accepts a private key. */
declare class SmartAccountClient {
    readonly client: SignedRestClient;
    constructor(client: SignedRestClient);
    private post;
    capabilities(): Promise<SmartAccountCapabilities>;
    prepareCreation(input: WalletCreationRequest, key?: string): Promise<{
        creation: WalletCreationPreparation;
    }>;
    challenge(input: BindingRequest): Promise<BindingChallenge>;
    bind(input: BindingRequest & {
        stateHash: Hex;
        signature: Hex;
    }, key?: string): Promise<SmartAccountBinding>;
    bindings(): Promise<{
        items: Pick<SmartAccountBinding, "id" | "wallet" | "manifestId">[];
    }>;
    binding(bindingId: Hex): Promise<SmartAccountBinding>;
    preparePlan(bindingId: Hex, operation: string, input: unknown, key?: string): Promise<SmartWalletPlan>;
    prepareSession(input: SessionPolicyInput, key?: string): Promise<StoredSession>;
    session(sessionId: string): Promise<StoredSession>;
    quota(sessionId: string): Promise<SessionQuota>;
    sessionPlan(sessionId: string, kind: "activation" | "revocation", compiledHash: Hex, key?: string): Promise<{
        session: StoredSession;
        plan: SmartWalletPlan;
        installationConfirmed: boolean;
    }>;
    prepareUserOperation(input: {
        planId: string;
        stepIndexes: number[];
        sessionId?: string;
    }, key?: string): Promise<PreparedUserOperation>;
    submitUserOperation(operationId: string, signature: Hex, key?: string): Promise<PreparedUserOperation>;
    userOperation(operationId: string): Promise<PreparedUserOperation>;
}
declare function verifyWalletCreation(input: {
    manifest: SmartAccountManifest;
    request: WalletCreationRequest;
    creation: WalletCreationPreparation;
}): {
    chainId: number;
    manifestId: string;
    manifestRevision: `0x${string}`;
    address: `0x${string}`;
    owners: `0x${string}`[];
    threshold: number;
    saltNonce: string;
    initializer: `0x${string}`;
    initializerHash: `0x${string}`;
    transaction: {
        to: `0x${string}`;
        value: "0";
        data: `0x${string}`;
    };
    initialAuthority: {
        validator: `0x${string}`;
        enabledSessions: number;
        executors: never[];
        hooks: never[];
        fallbacks: never[];
        registryEnforced: false;
    };
};
declare function assertReviewedOperation(record: PreparedUserOperation, plan: SmartWalletPlan, now?: number): void;
/** Concrete call template for one reviewed session action; the API still verifies deployment and available authority. */
declare function sessionActionPlanInput(session: StoredSession, input: {
    actionIndex?: number;
    uri?: string;
    amount?: string;
    tokenContractId?: string;
}): {
    account: `0x${string}`;
    calls: {
        contractId: string;
        projectId: string | undefined;
        function: string;
        args: (string | undefined)[];
        value: string | undefined;
        chainId: number;
        address: `0x${string}`;
    }[];
} | {
    account: `0x${string}`;
    calls: {
        contractId: string | undefined;
        function: string;
        args: (string | undefined)[];
        value: string;
        chainId: number;
        address: `0x${string}`;
    }[];
};
/** EIP-712 domains vary: request authentication, Safe binding and SafeOp use different fields. */
declare function walletTypedDataDocument(document: WalletTypedData): string;
declare function assertWalletIdentity(provider: WalletProvider, address: Address, chainId: number, stillCurrent?: () => boolean): Promise<void>;
declare function signWalletTypedData(input: {
    provider: WalletProvider;
    address: Address;
    chainId: number;
    document: WalletTypedData;
    stillCurrent?: () => boolean;
    signatureFormat?: "eoa" | "wallet";
}): Promise<Hex>;
/** Rebuild the exact binding document locally instead of signing arbitrary server-provided typed data. */
declare function smartBindingDocument(input: {
    audience: string;
    accountId: string;
    owner: Address;
    request: BindingRequest;
    challenge: BindingChallenge;
}, now?: number): WalletTypedData;
declare function packOwnerSignatures(input: {
    digest: Hex;
    owners: readonly Address[];
    threshold: number;
    signatures: readonly Hex[];
}): Promise<Hex>;
/** EOA signing view, also usable by the passkey profile's independent recovery EOA.
 * Passkey callers use PreparedUserOperation.signing's explicit profile and signedData.
 */
declare function ownerOperationSigning(input: Safe7579OwnerSigningInput & {
    record: PreparedUserOperation;
    binding: SmartAccountBinding;
}): OwnerSigningPayload;
/** Packs EOA signatures only. WebAuthn assertions require the profile's dynamic contract envelope. */
declare function ownerOperationSignature(payload: OwnerSigningPayload, binding: SmartAccountBinding, signatures: readonly Hex[]): Promise<`0x${string}`>;
declare function signSessionUserOperation(input: {
    record: PreparedUserOperation;
    session: StoredSession;
    signer: {
        address: Address;
        signMessage(input: {
            message: {
                raw: Hex;
            };
        }): Promise<Hex>;
    };
}): Promise<Hex>;

interface ForwardRequest {
    from: Address;
    to: Address;
    value: string;
    gas: string;
    nonce: string;
    deadline: string;
    data: Hex;
}
interface PreparedForwardRequest {
    stepIndex: number;
    chainId: number;
    forwarder: Address;
    forwarderCodeHash: Hex;
    targetCodeHash: Hex;
    domain: {
        name: string;
        version: string;
        chainId: number;
        verifyingContract: Address;
    };
    message: ForwardRequest;
    evidence: RestBlockEvidence;
}
interface SponsorshipSubmission {
    signatures: Hex[];
}

interface Plan {
    id: string;
    account: `0x${string}`;
    operation: string;
    commitment: Hex;
    draft: RestPlanDraft;
    createdAt: number;
    expiresAt: number;
    revision: number;
    status: "prepared" | "pending" | "partial" | "blocked" | "reorged" | "expired" | "transactions_confirmed";
    steps: {
        index: number;
        state: StepState;
        blockedBy: number[];
        receipt?: StoredReceipt;
        semantic?: SemanticResult;
        transaction?: {
            hash: Hex;
        };
        execution?: {
            hash?: Hex;
        };
    }[];
    confirmationScope: string;
}
interface PrepaidPreparation {
    id: string;
    planId: string;
    commitment: Hex;
    publicationExpiresAt: number;
    authorizations: PreparedForwardRequest[];
    state: "prepared" | "submitting" | "submission_unknown" | "quoted";
    availability: string;
    observations: {
        stepIndex: number;
        chainId: number;
        state: string;
        hash?: Hex;
    }[];
    quote?: {
        bundleUuid: string;
        runtimeVerified: boolean;
        payments: {
            chainId: number;
            value: string;
            deadline: string;
        }[];
    };
}
type ActionSigner = {
    address: `0x${string}`;
    signTypedData: {
        (document: ReturnType<typeof buildTransactionApprovalTypedData>): Promise<Hex>;
        (document: ReturnType<typeof buildSponsorshipApprovalTypedData>): Promise<Hex>;
    };
};
type TransactionSubmission = {
    planId: string;
    stepIndex: number;
    rawSignedTransaction: Hex;
    ownerApproval?: TransactionApproval;
};
type PrepaidSubmission = {
    sponsorshipId: string;
} & SponsorshipSubmission & {
    ownerApproval?: SponsorshipApproval;
};
/** Named workflows over the same exact-request signing and authorization protocol. */
declare class CenterClient {
    private readonly options;
    private readonly client;
    constructor(options: ClientOptions);
    request<T = unknown>(options: RequestOptions): Promise<T>;
    /** Authorizes one exact GET for a relay. Send the returned URL and headers unchanged; this method does not send it. */
    authorizeRead(requestTarget: string): Promise<PreparedRequest>;
    /** Uses this connection's existing API identity and grant on every execution network. */
    smartAccounts(): SmartAccountClient;
    /** Signs locally with the bot key after checking the exact plan and activated permission. Does not submit. */
    signSessionOperation(input: {
        plan: SmartWalletPlan;
        operation: PreparedUserOperation;
        session: StoredSession;
    }): Promise<Hex>;
    static forOwner(options: Omit<ClientOptions, "accountId" | "grantId"> & {
        chainId: number;
    }): CenterClient;
    static fromConnection(value: unknown, options?: Pick<ClientOptions, "fetch" | "timeoutMs" | "now">): CenterClient;
    account(): Promise<{
        account: Account;
    }>;
    enroll(): Promise<{
        account: Account;
    }>;
    bots(): Promise<{
        bots: BotGrant[];
    }>;
    revokeBot(grantId: string): Promise<{
        bot: BotGrant;
    }>;
    registerBot(input: {
        signer: RestSigner;
        scopes: BotScope[];
        label: string;
        expiresAt: number;
    }): Promise<{
        bot: BotGrant;
        client: CenterClient;
    }>;
    capabilities<T = Record<string, unknown>>(): Promise<T>;
    prepare(input: {
        operation: string;
        input: unknown;
    }, idempotencyKey: string): Promise<Plan>;
    plan(planId: string, options?: {
        refresh?: boolean;
    }): Promise<Plan>;
    simulate(planId: string, stepIndex: number): Promise<{
        simulated: true;
        planId: string;
        commitment: Hex;
        stepIndex: number;
        blockHash: Hex;
        blockNumber: string;
        result: Hex;
    }>;
    /** Call after the owner reviews the plan and the transaction wallet signs the exact bytes. */
    approveTransaction(input: {
        plan: Plan;
        stepIndex: number;
        rawSignedTransaction: Hex;
    }, owner: ActionSigner): Promise<TransactionSubmission>;
    submitTransaction(input: TransactionSubmission, idempotencyKey: string): Promise<{
        plan: Plan;
        dispatch: {
            status: string;
            hash: Hex;
            error?: {
                code: string;
                message: string;
            };
        };
    }>;
    preparePrepaid(planId: string, stepIndexes: number[] | undefined, idempotencyKey: string): Promise<PrepaidPreparation>;
    prepaid(sponsorshipId: string, options?: {
        refresh?: boolean;
    }): Promise<PrepaidPreparation>;
    approvePrepaid(preparation: PrepaidPreparation, signatures: Hex[], owner: ActionSigner): Promise<PrepaidSubmission>;
    submitPrepaid(input: PrepaidSubmission, idempotencyKey: string): Promise<PrepaidPreparation>;
    prepareFunding(sponsorshipId: string, chainId: number, payer: `0x${string}`, idempotencyKey: string): Promise<Plan>;
    private step;
    private approvalWindow;
}

interface CenterWalletStorage {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
interface CenterWalletClientOptions {
    /** Fixed trusted transport origin; never taken from a callback or discovery response. */
    issuer: string;
    audience: string;
    callbackUri: string;
    /** Defaults to this tab's sessionStorage. The adapter must preserve exact values across redirects. */
    storage?: CenterWalletStorage;
    fetch?: typeof fetch;
    /** Unix milliseconds. */
    now?: () => number;
    timeoutMs?: number;
    /** replace must remove the query using history.replaceState, without navigating. */
    location?: {
        href(): string;
        replace(url: string): void;
    };
}
interface CenterWalletConnection {
    readonly accountId: string;
    readonly address: Address;
    readonly chainId: 8453;
    /** Unix seconds. This is the original grant expiry, including after receipt recovery. */
    readonly expiresAt: number;
    readonly capabilities: readonly ['read', 'plan', 'relay'];
    /** API access only. Transactions still require fresh owner approval at Center. */
    readonly client: CenterClient;
}
interface CenterWalletPreparedConnection {
    readonly intentId: string;
    readonly authorizationUrl: string;
    readonly expiresAtMs: number;
}
/** Redirect continuity and exact receipt recovery for an app's local request key. No wallet owner key is created here. */
declare function createCenterWalletClient(options: CenterWalletClientOptions): Readonly<{
    prepareConnection: () => Promise<CenterWalletPreparedConnection>;
    completeConnection: (callbackUrl?: string) => Promise<CenterWalletConnection>;
    retryConnection: () => Promise<CenterWalletConnection>;
    restoreConnection: () => CenterWalletConnection | null;
    disconnect: () => void;
    payments: () => Readonly<{
        preparePayment: (input: CenterWalletPaymentInput) => Promise<CenterWalletPaymentStatus>;
        completePayment: (callbackUrl?: string) => Promise<CenterWalletPaymentStatus>;
        submitPayment: () => Promise<CenterWalletPaymentStatus>;
        refreshPayment: () => Promise<CenterWalletPaymentStatus>;
        pendingPayment: () => CenterWalletPaymentStatus | null;
        clearPayment: () => void;
    }>;
}>;

/** Exact call-derived review facts. Recognition conveys no execution or spending authority. */
interface WalletV6UsdcPayment {
    kind: "v6-usdc-pay";
    chainId: 8453;
    account: Address;
    token: Address;
    terminal: Address;
    projectId: string;
    amount: string;
    beneficiary: Address;
    minimumReturnedTokens: string;
    memo: string;
    metadata: Hex;
    stepIndexes: readonly number[];
    approvalStepIndexes: readonly number[];
    paymentStepIndex: number;
    resetAllowance: boolean;
}

type CenterWalletExpectedPayment = Omit<WalletV6UsdcPayment, 'stepIndexes' | 'approvalStepIndexes' | 'paymentStepIndex' | 'resetAllowance'> & {
    /** Maximum EntryPoint prefund in native wei, excluding separate rollup data fees. */
    maximumNetworkFee: string;
};
interface CenterWalletPaymentInput {
    plan: SmartWalletPlan;
    operation: PreparedUserOperation;
    expectedPayment: CenterWalletExpectedPayment;
}
type CenterWalletPaymentState = 'reviewing' | 'approved' | 'submitting' | 'pending' | 'confirming' | 'paid' | 'reverted' | 'cancelled' | 'unknown';
interface CenterWalletPaymentStatus {
    status: CenterWalletPaymentState;
    accountId: string;
    chainId: 8453;
    operationId: string;
    operationHash: Hex;
    reviewId: string | null;
    approvalUrl: string | null;
    expiresAtMs: number;
    expectedPayment: CenterWalletExpectedPayment;
    /** An observed outer transaction identifier, never an alias for operationHash. */
    transactionHash?: Hex;
    observation?: UserOperationObservation;
}

/** v0.7 required-prefund formula; unlike v0.6 it has separate paymaster gas limits. */
declare function userOperationMaximumCost(operation: UserOperationV07): bigint;

/** Local secret. Never send this document to Center or put it in a URL. */
interface BotConnection {
    format: "juicebox-center-connection-v1";
    audience: string;
    accountId: string;
    grantId: string;
    botAddress: Address;
    privateKey: Hex;
    scopes: BotScope[];
    expiresAt: number;
}
declare function parseConnection(value: unknown): BotConnection;
declare function connectionForBot(audience: string, bot: BotGrant, privateKey: Hex): BotConnection;

type TypedDocument = ReturnType<typeof buildRequestTypedData> | ReturnType<typeof buildBotProofTypedData>;

type RestSigner = {
    address: Address;
    /** Required only for locally signing operations under an activated bot wallet permission. */
    signMessage?(input: {
        message: {
            raw: Hex;
        };
    }): Promise<Hex>;
    signTypedData: {
        (document: ReturnType<typeof buildRequestTypedData>): Promise<Hex>;
        (document: ReturnType<typeof buildBotProofTypedData>): Promise<Hex>;
    };
};
type RequestOptions = {
    method?: string;
    /** Exact ASCII origin-form path including its already-encoded query. */
    requestTarget: string;
    json?: unknown;
    /** Raw bytes and json are mutually exclusive. Bytes are copied before signing. */
    body?: Uint8Array;
    contentType?: string;
    idempotencyKey?: string;
    /** Reserved for a bot proof bound to this owner's nonce. Such requests cannot auto-retry. */
    nonce?: Hex;
    retries?: number;
};
type ClientOptions = {
    audience: string;
    accountId: string;
    signer: RestSigner;
    grantId?: string;
    fetch?: typeof fetch;
    now?: () => number;
    timeoutMs?: number;
    maxResponseBytes?: number;
};
declare class RestClientError extends Error {
    readonly code: string;
    readonly status?: number | undefined;
    constructor(code: string, message: string, status?: number | undefined);
}
declare function clientAudience(value: string): string;
declare function exactRequestUrl(audience: string, requestTarget: string): string;
type PreparedRequest = {
    url: string;
    method: string;
    headers: Headers;
    body: Uint8Array;
    claims: RequestClaims;
};
/** Produces one signed request. The caller must send these exact bytes and URL. */
declare function prepareSignedRequest(config: ClientOptions, options: RequestOptions): Promise<PreparedRequest>;
/** Reads public discovery endpoints without asking the wallet for an authentication signature. */
declare function readPublicRestJson<T>(audience: string, requestTarget: string, transport?: typeof fetch): Promise<T>;
declare class SignedRestClient {
    private readonly config;
    constructor(config: ClientOptions);
    request<T = unknown>(options: RequestOptions): Promise<T>;
}
type BotRegistration = {
    format: "juicebox-center-bot-registration-v1";
    audience: string;
    accountId: string;
    ownerRequestNonce: Hex;
    registration: {
        botAddress: Address;
        scopes: BotScope[];
        expiresAt: number;
        label: string;
        proofSignature: Hex;
    };
};
declare function createBotRegistration(audience: string, proof: BotProof, signer: RestSigner): Promise<BotRegistration>;
/** Accepts public proof documents only. Private key fields are rejected, never forwarded. */
declare function parseBotRegistration(value: unknown): BotRegistration;

export { CenterClient, REST_AUTH_HEADERS, RestClientError, SignedRestClient, SmartAccountClient, accountIdFor, assertReviewedOperation, assertWalletIdentity, buildSponsorshipApprovalTypedData, buildTransactionApprovalTypedData, clientAudience, connectionForBot, createBotRegistration, createCenterWalletClient, exactRequestUrl, isCanonicalGrantScopes, newRequestNonce, ownerOperationSignature, ownerOperationSigning, packOwnerSignatures, parseBotRegistration, parseConnection, prepareSignedRequest, readPublicRestJson, sessionActionPlanInput, signSessionUserOperation, signWalletTypedData, smartBindingDocument, smartRequestKey, sponsorshipSubmissionHash, userOperationMaximumCost, verifyWalletCreation, walletTypedDataDocument };
export type { ActionSigner, BindingChallenge, BindingRequest, BotConnection, BotRegistration, CenterWalletClientOptions, CenterWalletConnection, CenterWalletExpectedPayment, CenterWalletPaymentInput, CenterWalletPaymentState, CenterWalletPaymentStatus, CenterWalletPreparedConnection, CenterWalletStorage, ClientOptions, OwnerSigningPayload, PasskeyOwnerSigningPayload, Plan, PrepaidPreparation, PrepaidSubmission, PreparedRequest, PreparedUserOperation, RequestOptions, RestSigner, SessionSigningPayload, SmartAccountCapabilities, SmartWalletPlan, SponsorshipApproval, SponsorshipApprovalBinding, SponsorshipApprovalClaims, TransactionApproval, TransactionApprovalBinding, TransactionApprovalClaims, TransactionSubmission, TypedDocument, WalletCreationPreparation, WalletCreationRequest, WalletProvider, WalletTypedData };
