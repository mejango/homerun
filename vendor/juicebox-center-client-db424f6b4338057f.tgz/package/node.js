import { CenterClient } from './index.js';
import { readProtectedDocument } from './cli.mjs';
export async function connect(filename, options) { return CenterClient.fromConnection(await readProtectedDocument(filename), options); }
