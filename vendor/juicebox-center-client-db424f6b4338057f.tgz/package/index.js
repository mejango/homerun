// src/rest/client/index.ts
import { getAddress as getAddress7, isAddress as isAddress9, keccak256 as keccak2569 } from "viem";

// src/rest/auth/signatures.ts
import {
  getAddress,
  hashTypedData,
  isAddress,
  keccak256,
  recoverTypedDataAddress,
  stringToHex,
  toHex
} from "viem";

// src/rest/auth/shared.ts
var ALL_BOT_SCOPES = ["read", "plan", "relay"];
var RestAuthError = class extends Error {
  constructor(code, status, message2) {
    super(message2);
    this.code = code;
    this.status = status;
    this.name = "RestAuthError";
  }
  code;
  status;
};
function isCanonicalGrantScopes(scopes) {
  return Array.isArray(scopes) && scopes.length >= 1 && scopes.length <= ALL_BOT_SCOPES.length && ALL_BOT_SCOPES.slice(0, scopes.length).every((scope, index) => scopes[index] === scope);
}

// src/rest/auth/signatures.ts
var REST_AUTH_HEADERS = {
  account: "X-Juicebox-Account",
  signer: "X-Juicebox-Signer",
  grant: "X-Juicebox-Grant",
  issuedAt: "X-Juicebox-Issued-At",
  expiresAt: "X-Juicebox-Expires-At",
  nonce: "X-Juicebox-Nonce",
  signature: "X-Juicebox-Signature",
  idempotencyKey: "Idempotency-Key"
};
var requestTypes = {
  CenterRequest: [
    { name: "audience", type: "string" },
    { name: "accountId", type: "string" },
    { name: "signer", type: "address" },
    { name: "grantId", type: "string" },
    { name: "method", type: "string" },
    { name: "requestTarget", type: "string" },
    { name: "contentType", type: "string" },
    { name: "bodyHash", type: "bytes32" },
    { name: "issuedAt", type: "uint64" },
    { name: "expiresAt", type: "uint64" },
    { name: "nonce", type: "bytes32" },
    { name: "idempotencyKey", type: "string" }
  ]
};
var botTypes = {
  CenterBotProof: [
    { name: "audience", type: "string" },
    { name: "accountId", type: "string" },
    { name: "botAddress", type: "address" },
    { name: "scopes", type: "string[]" },
    { name: "expiresAt", type: "uint64" },
    { name: "label", type: "string" },
    { name: "ownerRequestNonce", type: "bytes32" }
  ]
};
function invalid(message2 = "Invalid signed request") {
  throw new RestAuthError("INVALID_AUTH", 400, message2);
}
function validateAudience(audience) {
  let parsed;
  try {
    parsed = new URL(audience);
  } catch {
    return invalid("Invalid authentication audience");
  }
  if (parsed.username || parsed.password || parsed.search || parsed.hash || parsed.protocol !== "https:" && !(parsed.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(parsed.hostname))) {
    return invalid("Authentication audience must be HTTPS or local HTTP without credentials, query, or fragment");
  }
  return audience.replace(/\/$/, "");
}
function accountIdFor(owner, authorityChainId) {
  if (!Number.isSafeInteger(authorityChainId) || authorityChainId <= 0 || typeof owner !== "string" || !isAddress(owner)) {
    return invalid("Invalid account owner or authority chain");
  }
  return `eip155:${authorityChainId}:${owner.toLowerCase()}`;
}
function parseAccountId(accountId) {
  const match = /^eip155:([1-9][0-9]{0,15}):(0x[0-9a-f]{40})$/.exec(accountId);
  if (!match) return invalid("Invalid account identity");
  const authorityChainId = Number(match[1]);
  if (!Number.isSafeInteger(authorityChainId)) return invalid("Invalid authority chain");
  return { ownerAddress: getAddress(match[2]), authorityChainId };
}
function domain(audience, accountId) {
  return {
    name: "Juicebox Center REST",
    version: "1",
    chainId: parseAccountId(accountId).authorityChainId,
    salt: keccak256(stringToHex(audience))
  };
}
function buildRequestTypedData(audience, claims2) {
  audience = validateAudience(audience);
  return {
    domain: domain(audience, claims2.accountId),
    types: requestTypes,
    primaryType: "CenterRequest",
    message: {
      ...claims2,
      audience,
      issuedAt: BigInt(claims2.issuedAt),
      expiresAt: BigInt(claims2.expiresAt)
    }
  };
}
function buildBotProofTypedData(audience, proof) {
  audience = validateAudience(audience);
  return {
    domain: domain(audience, proof.accountId),
    types: botTypes,
    primaryType: "CenterBotProof",
    message: { ...proof, audience, expiresAt: BigInt(proof.expiresAt) }
  };
}
function newRequestNonce() {
  return toHex(globalThis.crypto.getRandomValues(new Uint8Array(32)));
}

// src/rest/approvals.ts
import {
  hashTypedData as hashTypedData2,
  keccak256 as keccak2562,
  recoverAddress,
  sha256,
  stringToHex as stringToHex2
} from "viem";

// src/rest/core.ts
var RestError = class extends Error {
  constructor(status, code, message2, details) {
    super(message2);
    this.status = status;
    this.code = code;
    this.details = details;
    this.name = "RestError";
  }
  status;
  code;
  details;
};

// src/rest/approvals.ts
var uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
var bytes32 = /^0x[0-9a-fA-F]{64}$/;
var types = {
  CenterTransactionApproval: [
    { name: "audience", type: "string" },
    { name: "accountId", type: "string" },
    { name: "principalId", type: "string" },
    { name: "planId", type: "string" },
    { name: "commitment", type: "bytes32" },
    { name: "stepIndex", type: "uint32" },
    { name: "transactionHash", type: "bytes32" },
    { name: "issuedAt", type: "uint64" },
    { name: "expiresAt", type: "uint64" },
    { name: "nonce", type: "bytes32" }
  ]
};
var sponsorshipTypes = {
  CenterSponsorshipApproval: [
    { name: "audience", type: "string" },
    { name: "accountId", type: "string" },
    { name: "principalId", type: "string" },
    { name: "sponsorshipId", type: "string" },
    { name: "commitment", type: "bytes32" },
    { name: "submissionHash", type: "bytes32" },
    { name: "issuedAt", type: "uint64" },
    { name: "expiresAt", type: "uint64" },
    { name: "nonce", type: "bytes32" }
  ]
};
function invalid2(message2 = "The owner approval is malformed") {
  throw new RestError(400, "INVALID_OWNER_APPROVAL", message2);
}
function time(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value > 0;
}
function identity(input) {
  if (!input || typeof input !== "object" || typeof input.accountId !== "string") return invalid2();
  try {
    parseAccountId(input.accountId);
  } catch {
    return invalid2("The approval account identity is invalid");
  }
  if (typeof input.principalId !== "string" || !(input.principalId === `owner:${input.accountId}` || input.principalId.startsWith("bot:") && uuid.test(input.principalId.slice(4)))) {
    return invalid2("The approval must identify an account principal");
  }
}
function binding(input) {
  identity(input);
  if (typeof input.planId !== "string" || !uuid.test(input.planId) || typeof input.commitment !== "string" || !bytes32.test(input.commitment) || typeof input.transactionHash !== "string" || !bytes32.test(input.transactionHash) || !Number.isSafeInteger(input.stepIndex) || Object.is(input.stepIndex, -0) || input.stepIndex < 0 || input.stepIndex > 31) {
    return invalid2("The approval must identify an account principal, plan, and exact transaction step");
  }
  return {
    accountId: input.accountId,
    principalId: input.principalId,
    planId: input.planId,
    commitment: input.commitment,
    stepIndex: input.stepIndex,
    transactionHash: input.transactionHash
  };
}
function claims(input) {
  const bound = binding(input);
  return { ...bound, ...window(input) };
}
function window(input) {
  if (!time(input.issuedAt) || !time(input.expiresAt) || input.expiresAt <= input.issuedAt || input.expiresAt - input.issuedAt > 300 || typeof input.nonce !== "string" || !/^0x[0-9a-f]{64}$/.test(input.nonce)) {
    return invalid2("The owner approval requires a validity window of at most five minutes and a 32-byte nonce");
  }
  return { issuedAt: input.issuedAt, expiresAt: input.expiresAt, nonce: input.nonce };
}
function buildTransactionApprovalTypedData(audience, input) {
  audience = validateAudience(audience);
  const value = claims(input);
  return {
    domain: {
      name: "Juicebox Center REST",
      version: "1",
      chainId: parseAccountId(value.accountId).authorityChainId,
      salt: keccak2562(stringToHex2(audience))
    },
    types,
    primaryType: "CenterTransactionApproval",
    message: { ...value, audience, issuedAt: BigInt(value.issuedAt), expiresAt: BigInt(value.expiresAt) }
  };
}
function sponsorshipBinding(input) {
  identity(input);
  if (typeof input.sponsorshipId !== "string" || !uuid.test(input.sponsorshipId) || typeof input.commitment !== "string" || !bytes32.test(input.commitment) || typeof input.submissionHash !== "string" || !bytes32.test(input.submissionHash)) return invalid2();
  return {
    accountId: input.accountId,
    principalId: input.principalId,
    sponsorshipId: input.sponsorshipId,
    commitment: input.commitment,
    submissionHash: input.submissionHash
  };
}
function buildSponsorshipApprovalTypedData(audience, input) {
  audience = validateAudience(audience);
  const value = { ...sponsorshipBinding(input), ...window(input) };
  return {
    domain: {
      name: "Juicebox Center REST",
      version: "1",
      chainId: parseAccountId(value.accountId).authorityChainId,
      salt: keccak2562(stringToHex2(audience))
    },
    types: sponsorshipTypes,
    primaryType: "CenterSponsorshipApproval",
    message: { ...value, audience, issuedAt: BigInt(value.issuedAt), expiresAt: BigInt(value.expiresAt) }
  };
}
function sponsorshipSubmissionHash(commitment, signatures) {
  if (typeof commitment !== "string" || !bytes32.test(commitment) || !Array.isArray(signatures) || signatures.length < 1 || signatures.length > 4 || Array.from(signatures).some((signature2) => typeof signature2 !== "string" || !/^0x[0-9a-fA-F]{130}$/.test(signature2))) return invalid2();
  return sha256(stringToHex2(JSON.stringify({ commitment: commitment.toLowerCase(), signatures: signatures.map((signature2) => signature2.toLowerCase()) })));
}

// src/rest/client/smartAccounts.ts
import {
  concatHex as concatHex4,
  hashTypedData as hashTypedData4,
  isAddress as isAddress6,
  keccak256 as keccak2565,
  recoverAddress as recoverAddress3,
  stringToHex as stringToHex4
} from "viem";

// src/rest/smartAccounts/accountExecution.ts
import {
  concatHex,
  decodeAbiParameters,
  decodeFunctionData,
  encodeAbiParameters as encodeAbiParameters2,
  encodeFunctionData,
  getAddress as getAddress3,
  hashMessage,
  hashTypedData as hashTypedData3,
  parseAbi,
  parseAbiParameters,
  recoverAddress as recoverAddress2,
  size,
  sliceHex,
  toHex as toHex3
} from "viem";

// src/rest/protocol/abi.ts
import {
  getAddress as getAddress2,
  isAddress as isAddress2
} from "viem";
var MAX_UINT256 = (1n << 256n) - 1n;
var invalid3 = (path, message2) => {
  throw new RestError(400, "ABI_ARGUMENT_INVALID", `${path}: ${message2}`);
};
function integer(value, path, signed = false, bits = 256) {
  if (typeof value !== "string" || value.length > 79 || !(signed ? /^(0|-[1-9][0-9]*|[1-9][0-9]*)$/ : /^(0|[1-9][0-9]*)$/).test(
    value
  ))
    return invalid3(
      path,
      "Use an exact canonical decimal integer string; JSON numbers, exponents and leading zeros are not accepted."
    );
  const n = BigInt(value);
  const minimum = signed ? -(1n << BigInt(bits - 1)) : 0n;
  const maximum = signed ? (1n << BigInt(bits - 1)) - 1n : (1n << BigInt(bits)) - 1n;
  if (n < minimum || n > maximum)
    return invalid3(
      path,
      `Value does not fit ${signed ? "int" : "uint"}${bits}.`
    );
  return n;
}
function address(value, path, nonzero = false) {
  if (typeof value !== "string" || !isAddress2(value, { strict: true }))
    return invalid3(
      path,
      "Use a valid EVM address, with a valid checksum when mixed case."
    );
  const result = getAddress2(value);
  if (nonzero && BigInt(result) === 0n)
    return invalid3(path, "Address must be nonzero.");
  return result;
}
function exactObject(value, keys, path) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype)
    return invalid3(path, "Expected a JSON object.");
  if (Object.keys(value).some((key) => !keys.includes(key)))
    return invalid3(
      path,
      "Unknown input field; caller ABIs, raw calldata and upstream URLs are not accepted."
    );
}

// src/rest/userOperations/codec.ts
import {
  concat,
  encodeAbiParameters,
  isAddress as isAddress3,
  keccak256 as keccak2563,
  padHex,
  sha256 as sha2562,
  stringToHex as stringToHex3,
  toHex as toHex2
} from "viem";
var USER_OPERATION_LIMITS = Object.freeze({
  responseBytes: 1048576,
  operationBytes: 262144,
  calldataBytes: 65536,
  signatureBytes: 16384,
  paymasterBytes: 8192,
  factoryBytes: 32768,
  rpcCalls: 96
});
function uoError(code, message2, status = 422) {
  throw new RestError(status, code, message2);
}
function uoObject(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function uoQuantity(value, label, bits = 256) {
  if (typeof value !== "string" || !/^0x(0|[1-9a-f][0-9a-f]{0,63})$/.test(value) || BigInt(value) >= 1n << BigInt(bits))
    uoError("INVALID_USER_OPERATION", `Invalid canonical ${label}.`, 400);
  return BigInt(value);
}
function uoBytes(value, label, maximum = USER_OPERATION_LIMITS.calldataBytes) {
  if (typeof value !== "string" || !/^0x(?:[0-9a-fA-F]{2})*$/.test(value) || (value.length - 2) / 2 > maximum)
    uoError("INVALID_USER_OPERATION", `Invalid bounded ${label}.`, 400);
  return value.toLowerCase();
}
function uoAddress(value, label) {
  if (typeof value !== "string" || !isAddress3(value) || /^0x0{40}$/i.test(value))
    uoError("INVALID_USER_OPERATION", `Invalid ${label}.`, 400);
  return value.toLowerCase();
}
function uoCanonical(value) {
  if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isSafeInteger(value))
    return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(uoCanonical).join(",")}]`;
  if (uoObject(value))
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${uoCanonical(value[key])}`).join(",")}}`;
  return uoError(
    "INVALID_USER_OPERATION",
    "Only bounded lossless JSON is accepted.",
    400
  );
}
var required = [
  "sender",
  "nonce",
  "callData",
  "callGasLimit",
  "verificationGasLimit",
  "preVerificationGas",
  "maxFeePerGas",
  "maxPriorityFeePerGas",
  "signature"
];
var optional = [
  "factory",
  "factoryData",
  "paymaster",
  "paymasterVerificationGasLimit",
  "paymasterPostOpGasLimit",
  "paymasterData"
];
function normalizeUserOperation(value) {
  if (!uoObject(value) || required.some((key) => !(key in value)) || Object.keys(value).some((key) => ![...required, ...optional].includes(key)))
    uoError(
      "INVALID_USER_OPERATION",
      "Provide only the complete unpacked EntryPoint v0.7 fields.",
      400
    );
  const result = {
    sender: uoAddress(value.sender, "sender"),
    nonce: toHex2(uoQuantity(value.nonce, "nonce")),
    callData: uoBytes(value.callData, "account calldata"),
    callGasLimit: toHex2(uoQuantity(value.callGasLimit, "call gas", 128)),
    verificationGasLimit: toHex2(
      uoQuantity(value.verificationGasLimit, "verification gas", 128)
    ),
    preVerificationGas: toHex2(
      uoQuantity(value.preVerificationGas, "pre-verification gas")
    ),
    maxFeePerGas: toHex2(uoQuantity(value.maxFeePerGas, "maximum fee", 128)),
    maxPriorityFeePerGas: toHex2(
      uoQuantity(value.maxPriorityFeePerGas, "priority fee", 128)
    ),
    signature: uoBytes(
      value.signature,
      "account signature",
      USER_OPERATION_LIMITS.signatureBytes
    )
  };
  if (BigInt(result.maxPriorityFeePerGas) > BigInt(result.maxFeePerGas))
    uoError("INVALID_USER_OPERATION", "Priority fee exceeds maximum fee.", 400);
  if ("factory" in value || "factoryData" in value) {
    result.factory = uoAddress(value.factory, "factory");
    if (result.factory === "0x0000000000000000000000000000000000007702" || result.factory === "0x7702000000000000000000000000000000000000")
      uoError(
        "USER_OPERATION_VERSION_UNSUPPORTED",
        "EIP-7702 authorization is not an EntryPoint v0.7 factory.",
        400
      );
    result.factoryData = uoBytes(
      value.factoryData,
      "factory calldata",
      USER_OPERATION_LIMITS.factoryBytes
    );
  }
  if (optional.slice(2).some((key) => key in value)) {
    result.paymaster = uoAddress(value.paymaster, "paymaster");
    result.paymasterData = uoBytes(
      value.paymasterData,
      "paymaster data",
      USER_OPERATION_LIMITS.paymasterBytes
    );
    result.paymasterVerificationGasLimit = toHex2(
      uoQuantity(
        value.paymasterVerificationGasLimit,
        "paymaster verification gas",
        128
      )
    );
    result.paymasterPostOpGasLimit = toHex2(
      uoQuantity(value.paymasterPostOpGasLimit, "paymaster post-op gas", 128)
    );
  }
  if (new TextEncoder().encode(uoCanonical(result)).byteLength > USER_OPERATION_LIMITS.operationBytes)
    uoError(
      "USER_OPERATION_TOO_LARGE",
      "The user operation exceeds its byte limit.",
      413
    );
  return result;
}
function packUserOperation(value) {
  const op = normalizeUserOperation(value);
  return {
    sender: op.sender,
    nonce: BigInt(op.nonce),
    initCode: op.factory ? concat([op.factory, op.factoryData]) : "0x",
    callData: op.callData,
    accountGasLimits: concat([
      padHex(op.verificationGasLimit, { size: 16 }),
      padHex(op.callGasLimit, { size: 16 })
    ]),
    preVerificationGas: BigInt(op.preVerificationGas),
    gasFees: concat([
      padHex(op.maxPriorityFeePerGas, { size: 16 }),
      padHex(op.maxFeePerGas, { size: 16 })
    ]),
    paymasterAndData: op.paymaster ? concat([
      op.paymaster,
      padHex(op.paymasterVerificationGasLimit, { size: 16 }),
      padHex(op.paymasterPostOpGasLimit, { size: 16 }),
      op.paymasterData
    ]) : "0x",
    signature: op.signature
  };
}
function getUserOperationHash(operation, entryPoint, chainId) {
  if (!Number.isSafeInteger(chainId) || chainId <= 0)
    uoError(
      "INVALID_USER_OPERATION_CHAIN",
      "Expected a configured chain.",
      400
    );
  const op = packUserOperation(operation);
  const encoded = encodeAbiParameters(
    [
      { type: "address" },
      { type: "uint256" },
      { type: "bytes32" },
      { type: "bytes32" },
      { type: "bytes32" },
      { type: "uint256" },
      { type: "bytes32" },
      { type: "bytes32" }
    ],
    [
      op.sender,
      op.nonce,
      keccak2563(op.initCode),
      keccak2563(op.callData),
      op.accountGasLimits,
      op.preVerificationGas,
      op.gasFees,
      keccak2563(op.paymasterAndData)
    ]
  );
  return keccak2563(
    encodeAbiParameters(
      [{ type: "bytes32" }, { type: "address" }, { type: "uint256" }],
      [
        keccak2563(encoded),
        uoAddress(entryPoint, "EntryPoint"),
        BigInt(chainId)
      ]
    )
  );
}
function userOperationCommitment(operation, entryPoint, chainId) {
  if (!Number.isSafeInteger(chainId) || chainId <= 0)
    uoError(
      "INVALID_USER_OPERATION_CHAIN",
      "Expected a configured chain.",
      400
    );
  return sha2562(
    stringToHex3(
      uoCanonical({
        chainId,
        entryPoint: uoAddress(entryPoint, "EntryPoint"),
        operation: normalizeUserOperation(operation)
      })
    )
  );
}
function userOperationMaximumCost(operation) {
  const op = normalizeUserOperation(operation);
  return (BigInt(op.callGasLimit) + BigInt(op.verificationGasLimit) + BigInt(op.preVerificationGas) + BigInt(op.paymasterVerificationGasLimit ?? "0x0") + BigInt(op.paymasterPostOpGasLimit ?? "0x0")) * BigInt(op.maxFeePerGas);
}

// src/rest/smartAccounts/accountExecution.ts
var SAFE7579_EXECUTION_ABI = parseAbi([
  "function execute(bytes32 mode, bytes executionCalldata)"
]);
var executionsParameter = parseAbiParameters(
  "(address target, uint256 value, bytes callData)[]"
);
var SAFE7579_SINGLE_MODE = `0x${"00".repeat(32)}`;
var SAFE7579_BATCH_MODE = `0x01${"00".repeat(31)}`;
var MAX_EXECUTIONS = 16;
var MAX_EXECUTION_BYTES = 65536;
function fail(message2) {
  throw new RestError(400, "SMART_ACCOUNT_ENVELOPE_INVALID", message2);
}
function hex(value, label, minimum, maximum) {
  if (typeof value !== "string" || !/^0x(?:[0-9a-fA-F]{2})*$/.test(value) || (value.length - 2) / 2 < minimum || (value.length - 2) / 2 > maximum)
    fail(`${label} must contain ${minimum} to ${maximum} complete bytes.`);
  return value.toLowerCase();
}
function callsChecked(calls) {
  if (!Array.isArray(calls) || calls.length < 1 || calls.length > MAX_EXECUTIONS)
    fail(`An execution must contain 1 to ${MAX_EXECUTIONS} exact calls.`);
  return calls.map((call, index) => {
    exactObject(call, ["target", "value", "callData"], `calls[${index}]`);
    return {
      target: address(call.target, `calls[${index}].target`, true),
      value: integer(call.value, `calls[${index}].value`).toString(),
      callData: hex(
        call.callData,
        `calls[${index}].callData`,
        0,
        MAX_EXECUTION_BYTES
      )
    };
  });
}
function decodeSafe7579Nonce(nonce) {
  const value = integer(nonce, "nonce");
  const validator = getAddress3(toHex3(value >> 96n, { size: 20 }));
  if (BigInt(validator) === 0n)
    fail("A session nonce must select a nonzero validator.");
  return {
    validator,
    lane: (value >> 64n & 0xffffffffn).toString(),
    sequence: (value & 0xffffffffffffffffn).toString(),
    key: (value >> 64n).toString()
  };
}
function encodeLegacyUseSignature(permissionId, signature2) {
  const permission = hex(permissionId, "permissionId", 32, 32);
  if (BigInt(permission) === 0n) fail("A permission ID must be nonzero.");
  return concatHex(["0x00", permission, hex(signature2, "signature", 1, 4096)]);
}
function encodeSafe7579Execution(calls) {
  const checked = callsChecked(calls);
  const first = checked[0];
  const mode = checked.length === 1 ? SAFE7579_SINGLE_MODE : SAFE7579_BATCH_MODE;
  const executionCalldata = checked.length === 1 ? concatHex([
    first.target,
    toHex3(BigInt(first.value), { size: 32 }),
    first.callData
  ]) : encodeAbiParameters2(executionsParameter, [
    checked.map((call) => ({
      ...call,
      value: BigInt(call.value)
    }))
  ]);
  const encoded = encodeFunctionData({
    abi: SAFE7579_EXECUTION_ABI,
    functionName: "execute",
    args: [mode, executionCalldata]
  });
  if (size(encoded) > MAX_EXECUTION_BYTES)
    fail("The complete execution exceeds the byte limit.");
  return encoded.toLowerCase();
}
function decodeSafe7579Execution(callData) {
  const data = hex(callData, "execution", 4, MAX_EXECUTION_BYTES);
  try {
    const decoded = decodeFunctionData({ abi: SAFE7579_EXECUTION_ABI, data });
    const [mode, execution] = decoded.args;
    let calls;
    if (mode === SAFE7579_SINGLE_MODE) {
      if (size(execution) < 52)
        fail("A packed single execution requires target and value.");
      calls = [
        {
          target: getAddress3(sliceHex(execution, 0, 20)),
          value: BigInt(sliceHex(execution, 20, 52)).toString(),
          // viem rejects a slice starting at the end of an exact target/value body.
          callData: size(execution) === 52 ? "0x" : sliceHex(execution, 52)
        }
      ];
    } else if (mode === SAFE7579_BATCH_MODE) {
      const [batch] = decodeAbiParameters(executionsParameter, execution);
      if (batch.length < 2)
        fail("Canonical batches contain at least two calls.");
      calls = batch.map((call) => ({ ...call, value: call.value.toString() }));
    } else
      fail("Only default single or batch CALL execution modes are accepted.");
    if (encodeSafe7579Execution(calls) !== data)
      fail("The execution must use its exact canonical ABI encoding.");
    return calls;
  } catch (error) {
    if (error instanceof RestError) throw error;
    return fail("The account execution cannot be decoded canonically.");
  }
}
function assertSafe7579Execution(callData, expectedCalls) {
  const decoded = decodeSafe7579Execution(callData);
  if (encodeSafe7579Execution(expectedCalls) !== callData.toLowerCase())
    fail(
      "The execution differs from the exact approved calls, values, or ordering."
    );
  return decoded;
}
var SAFE7579_OWNER_TYPES = {
  EIP712Domain: [
    { name: "chainId", type: "uint256" },
    { name: "verifyingContract", type: "address" }
  ],
  SafeOp: [
    { name: "safe", type: "address" },
    { name: "nonce", type: "uint256" },
    { name: "initCode", type: "bytes" },
    { name: "callData", type: "bytes" },
    { name: "verificationGasLimit", type: "uint128" },
    { name: "callGasLimit", type: "uint128" },
    { name: "preVerificationGas", type: "uint256" },
    { name: "maxPriorityFeePerGas", type: "uint128" },
    { name: "maxFeePerGas", type: "uint128" },
    { name: "paymasterAndData", type: "bytes" },
    { name: "validAfter", type: "uint48" },
    { name: "validUntil", type: "uint48" },
    { name: "entryPoint", type: "address" }
  ]
};
function safe7579OwnerSigningPayload(input) {
  const operation = normalizeUserOperation(input.operation);
  if (BigInt(operation.nonce) >> 96n)
    fail("Owner signing requires a zero-validator nonce.");
  if (!Number.isSafeInteger(input.chainId) || input.chainId <= 0)
    fail("Use the verified execution chain.");
  const validAfter = integer(input.validAfter, "validAfter", false, 48);
  const validUntil = integer(input.validUntil, "validUntil", false, 48);
  if (validUntil <= validAfter)
    fail("Owner operations require a finite ordered validity interval.");
  const packed = packUserOperation(operation);
  const typedData = {
    domain: {
      chainId: BigInt(input.chainId),
      verifyingContract: address(input.safe7579, "safe7579", true)
    },
    types: SAFE7579_OWNER_TYPES,
    primaryType: "SafeOp",
    message: {
      safe: operation.sender,
      nonce: BigInt(operation.nonce),
      initCode: packed.initCode,
      callData: operation.callData,
      verificationGasLimit: BigInt(operation.verificationGasLimit),
      callGasLimit: BigInt(operation.callGasLimit),
      preVerificationGas: BigInt(operation.preVerificationGas),
      maxPriorityFeePerGas: BigInt(operation.maxPriorityFeePerGas),
      maxFeePerGas: BigInt(operation.maxFeePerGas),
      paymasterAndData: packed.paymasterAndData,
      validAfter: Number(validAfter),
      validUntil: Number(validUntil),
      entryPoint: address(input.entryPoint, "entryPoint", true)
    }
  };
  const digest = hashTypedData3(typedData);
  return {
    scheme: "eip712-safe7579-owner",
    digest,
    // JSON-safe eth_signTypedData_v4 payload; uint values remain exact decimal strings.
    typedData: {
      ...typedData,
      domain: { ...typedData.domain, chainId: input.chainId },
      message: {
        ...typedData.message,
        nonce: typedData.message.nonce.toString(),
        verificationGasLimit: typedData.message.verificationGasLimit.toString(),
        callGasLimit: typedData.message.callGasLimit.toString(),
        preVerificationGas: typedData.message.preVerificationGas.toString(),
        maxPriorityFeePerGas: typedData.message.maxPriorityFeePerGas.toString(),
        maxFeePerGas: typedData.message.maxFeePerGas.toString(),
        validAfter: validAfter.toString(),
        validUntil: validUntil.toString()
      }
    },
    validAfter: validAfter.toString(),
    validUntil: validUntil.toString()
  };
}
var SECP256K1_ORDER = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;
function canonicalEoaSignature(value) {
  const signature2 = hex(value, "ECDSA signature", 65, 65);
  const r = BigInt(sliceHex(signature2, 0, 32));
  const s = BigInt(sliceHex(signature2, 32, 64));
  const v = Number(BigInt(sliceHex(signature2, 64)));
  if (r === 0n || r >= SECP256K1_ORDER || s === 0n || s > SECP256K1_ORDER / 2n || v !== 27 && v !== 28)
    fail("Use canonical low-s ECDSA signatures with recovery byte 27 or 28.");
  return signature2;
}
function encodeSafe7579OwnerSignature(input) {
  const after = integer(input.validAfter, "validAfter", false, 48);
  const until = integer(input.validUntil, "validUntil", false, 48);
  if (until <= after)
    fail("Owner operations require a finite ordered validity interval.");
  const signatures = hex(input.signatures, "owner signatures", 65, 16 * 65);
  if (size(signatures) % 65 !== 0)
    fail("Owner signatures must be exact 65-byte entries.");
  for (let offset = 0; offset < size(signatures); offset += 65)
    canonicalEoaSignature(sliceHex(signatures, offset, offset + 65));
  return concatHex([
    toHex3(after, { size: 6 }),
    toHex3(until, { size: 6 }),
    signatures
  ]);
}
function legacySessionSigningPayload(input) {
  const operation = normalizeUserOperation(input.operation);
  const selected = decodeSafe7579Nonce(BigInt(operation.nonce).toString());
  if (selected.validator.toLowerCase() !== address(input.smartSessions, "smartSessions", true).toLowerCase())
    fail("The nonce must select the exact installed SmartSession validator.");
  const permissionId = hex(input.permissionId, "permissionId", 32, 32);
  if (BigInt(permissionId) === 0n) fail("A permission ID must be nonzero.");
  const operationHash = getUserOperationHash(
    operation,
    input.entryPoint,
    input.chainId
  );
  return {
    scheme: "eip191-legacy-ownable-user-operation",
    operationHash,
    digest: hashMessage({ raw: operationHash }),
    message: { raw: operationHash },
    permissionId,
    /** The prefix is an envelope selector, not an additional field in the signed UserOp hash. */
    signaturePrefix: concatHex(["0x00", permissionId])
  };
}

// src/rest/smartAccounts/creation.ts
import {
  concatHex as concatHex3,
  decodeFunctionData as decodeFunctionData2,
  encodeAbiParameters as encodeAbiParameters4,
  encodeFunctionData as encodeFunctionData2,
  getAddress as getAddress4,
  getContractAddress as getContractAddress2,
  isAddress as isAddress5,
  keccak256 as keccak2564,
  parseAbi as parseAbi2,
  sliceHex as sliceHex2,
  toHex as toHex4,
  zeroAddress
} from "viem";

// src/rest/smartAccounts/passkeyCreation.ts
import {
  concatHex as concatHex2,
  encodeAbiParameters as encodeAbiParameters3,
  getContractAddress,
  isAddress as isAddress4,
  zeroHash
} from "viem";

// src/rest/smartAccounts/creation.ts
var SAFE_141_PROXY_CREATION_CODE = "0x608060405234801561001057600080fd5b506040516101e63803806101e68339818101604052602081101561003357600080fd5b8101908080519060200190929190505050600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff1614156100ca576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260228152602001806101c46022913960400191505060405180910390fd5b806000806101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055505060ab806101196000396000f3fe608060405273ffffffffffffffffffffffffffffffffffffffff600054167fa619486e0000000000000000000000000000000000000000000000000000000060003514156050578060005260206000f35b3660008037600080366000845af43d6000803e60008114156070573d6000fd5b3d6000f3fea264697066735822122003d1488ee65e08fa41e58e888a9865554c535f2c77126a82cb4c0f917f31441364736f6c63430007060033496e76616c69642073696e676c65746f6e20616464726573732070726f7669646564";
var SAFE_CREATION_ABI = parseAbi2([
  "function createProxyWithNonce(address singleton,bytes initializer,uint256 saltNonce) returns(address proxy)",
  "event ProxyCreation(address indexed proxy,address singleton)"
]);
var SAFE_SETUP_ABI = parseAbi2([
  "function setup(address[] owners,uint256 threshold,address to,bytes data,address fallbackHandler,address paymentToken,uint256 payment,address paymentReceiver)"
]);
var SAFE7579_LAUNCH_SETUP_ABI = parseAbi2([
  "function addSafe7579(address safe7579,(address module,bytes initData,uint256 moduleType)[] modules,address[] attesters,uint8 threshold)"
]);
var MULTI_SEND_ABI = parseAbi2(["function multiSend(bytes transactions)"]);
var SIGNER_FACTORY_ABI = parseAbi2(["function createSigner(uint256 x,uint256 y,uint176 verifiers) returns(address)"]);
function invalid4() {
  throw new RestError(
    422,
    "SMART_CREATION_UNSUPPORTED",
    "Use the reviewed atomic Safe 1.4.1 setup with an empty SmartSession validator and no payment."
  );
}
function validateCreationInput(input) {
  const { manifest: m } = input;
  if (m.safeVersion !== "1.4.1" || m.smartSessions.generation !== "legacy-validator" || m.safe7579.source.commit !== "f22a194148ff087f0c16125e530512e59794e188" || !Array.isArray(input.owners) || input.owners.length < 1 || input.owners.length > 16 || Array.from({ length: input.owners.length }, (_, i) => i).some(
    (i) => !Object.hasOwn(input.owners, i) || !isAddress5(input.owners[i]) || BigInt(input.owners[i]) <= 1n
  ) || new Set(input.owners.map((a) => a.toLowerCase())).size !== input.owners.length || !Number.isSafeInteger(input.threshold) || input.threshold < 1 || input.threshold > input.owners.length || typeof input.saltNonce !== "string" || !/^(0|[1-9][0-9]*)$/.test(input.saltNonce) || input.saltNonce.length > 78 || BigInt(input.saltNonce) >= 1n << 256n)
    invalid4();
}
function launchpadSetup(m) {
  return encodeFunctionData2({
    abi: SAFE7579_LAUNCH_SETUP_ABI,
    functionName: "addSafe7579",
    args: [
      m.safe7579.address,
      [{ module: m.smartSessions.address, initData: "0x", moduleType: 1n }],
      [],
      0
    ]
  });
}
function assembleCreation(input, setupTarget, setupData) {
  validateCreationInput(input);
  const m = input.manifest, owners = input.owners.map((a) => getAddress4(a));
  const initializer = encodeFunctionData2({
    abi: SAFE_SETUP_ABI,
    functionName: "setup",
    args: [
      owners,
      BigInt(input.threshold),
      setupTarget,
      setupData,
      m.safe7579.address,
      zeroAddress,
      0n,
      zeroAddress
    ]
  });
  const initializerHash = keccak2564(initializer);
  const salt = keccak2564(
    concatHex3([
      initializerHash,
      encodeAbiParameters4([{ type: "uint256" }], [BigInt(input.saltNonce)])
    ])
  );
  const bytecode = concatHex3([
    SAFE_141_PROXY_CREATION_CODE,
    encodeAbiParameters4([{ type: "address" }], [m.singleton.address])
  ]);
  const address3 = getContractAddress2({
    from: m.factory.address,
    opcode: "CREATE2",
    salt,
    bytecode
  });
  return {
    chainId: m.chainId,
    manifestId: m.id,
    manifestRevision: m.revision,
    address: address3,
    owners,
    threshold: input.threshold,
    saltNonce: input.saltNonce,
    initializer,
    initializerHash,
    transaction: {
      to: m.factory.address,
      value: "0",
      data: encodeFunctionData2({
        abi: SAFE_CREATION_ABI,
        functionName: "createProxyWithNonce",
        args: [m.singleton.address, initializer, BigInt(input.saltNonce)]
      })
    },
    initialAuthority: {
      validator: m.smartSessions.address,
      enabledSessions: 0,
      executors: [],
      hooks: [],
      fallbacks: [],
      registryEnforced: false
    }
  };
}
function prepareSafe7579Creation(input) {
  if (input.manifest.creationProfile !== void 0) invalid4();
  validateCreationInput(input);
  return assembleCreation(input, input.manifest.launchpad.address, launchpadSetup(input.manifest));
}

// src/rest/client/smartAccounts.ts
var prefix = "/api/v1";
var same = (a, b) => a.toLowerCase() === b.toLowerCase();
var invalid5 = (message2) => {
  throw new RestClientError("SMART_CLIENT_INVALID", message2);
};
var id = (value) => {
  if (!/^(?:0x[0-9a-fA-F]{64}|[A-Za-z0-9_-]{1,128})$/.test(value))
    invalid5("Use the exact identifier returned by the service.");
  return encodeURIComponent(value);
};
function smartRequestKey() {
  return `smart-${newRequestNonce().slice(2)}`;
}
var SmartAccountClient = class {
  constructor(client) {
    this.client = client;
  }
  client;
  post(path, json, key = smartRequestKey()) {
    return this.client.request({
      method: "POST",
      requestTarget: `${prefix}${path}`,
      json,
      idempotencyKey: key
    });
  }
  capabilities() {
    return this.client.request({
      requestTarget: `${prefix}/smart-accounts/capabilities`
    });
  }
  prepareCreation(input, key) {
    return this.post(
      "/smart-accounts/creation-plans",
      input,
      key
    );
  }
  challenge(input) {
    return this.post(
      "/smart-accounts/binding-challenges",
      input
    );
  }
  bind(input, key) {
    return this.post(
      "/smart-accounts/bindings",
      input,
      key
    );
  }
  bindings() {
    return this.client.request({ requestTarget: `${prefix}/smart-accounts/bindings` });
  }
  binding(bindingId) {
    return this.client.request({
      requestTarget: `${prefix}/smart-accounts/bindings/${id(bindingId)}`
    });
  }
  preparePlan(bindingId, operation, input, key) {
    return this.post(
      `/smart-accounts/bindings/${id(bindingId)}/plans`,
      { operation, input },
      key
    );
  }
  prepareSession(input, key) {
    return this.post("/smart-accounts/sessions", input, key);
  }
  session(sessionId) {
    return this.client.request({
      requestTarget: `${prefix}/smart-accounts/sessions/${id(sessionId)}`
    });
  }
  quota(sessionId) {
    return this.client.request({
      requestTarget: `${prefix}/smart-accounts/sessions/${id(sessionId)}/quota`
    });
  }
  sessionPlan(sessionId, kind, compiledHash, key) {
    return this.post(
      `/smart-accounts/sessions/${id(sessionId)}/${kind}-plans`,
      { compiledHash },
      key
    );
  }
  prepareUserOperation(input, key) {
    return this.post("/user-operations", input, key);
  }
  submitUserOperation(operationId, signature2, key) {
    if (!/^0x(?:[0-9a-fA-F]{2}){65,16384}$/.test(signature2))
      invalid5("Use a complete owner or session signature envelope.");
    return this.post(
      `/user-operations/${id(operationId)}/submissions`,
      { signature: signature2 },
      key
    );
  }
  userOperation(operationId) {
    return this.client.request({
      requestTarget: `${prefix}/user-operations/${id(operationId)}`
    });
  }
};
function verifyWalletCreation(input) {
  const expected = prepareSafe7579Creation({
    manifest: input.manifest,
    ...input.request
  });
  const actual = input.creation;
  if (input.request.manifestId !== input.manifest.id || actual.chainId !== expected.chainId || actual.manifestId !== expected.manifestId || !same(actual.manifestRevision, expected.manifestRevision) || !same(actual.address, expected.address) || !same(actual.initializerHash, expected.initializerHash) || !same(actual.transaction.to, expected.transaction.to) || actual.transaction.value !== "0" || !same(actual.transaction.data, expected.transaction.data))
    invalid5(
      "Wallet creation differs from the selected deployment, owners or threshold."
    );
  return expected;
}
function assertReviewedOperation(record, plan, now = Date.now()) {
  if (record.state !== "prepared" || record.expiresAt <= now || record.createdAt > now + 3e4 || record.planId !== plan.id || !same(record.planCommitment, plan.commitment) || !plan.smartAccount || !same(record.accountBindingId, plan.smartAccount.bindingId) || record.chainId !== plan.smartAccount.chainId || !same(record.operation.sender, plan.smartAccount.address) || record.operation.signature !== "0x" || !record.stepIndexes.length || new Set(record.stepIndexes).size !== record.stepIndexes.length)
    invalid5(
      "Prepare a fresh operation for the exact reviewed plan and wallet."
    );
  const calls = record.stepIndexes.map((index) => {
    const call = Number.isSafeInteger(index) && index >= 0 ? plan.draft.calls[index] : void 0;
    if (!call || call.chainId !== record.chainId)
      return invalid5("The operation selects an invalid plan step.");
    return { target: call.to, value: call.value, callData: call.data };
  });
  assertSafe7579Execution(record.operation.callData, calls);
  if (!same(
    record.operationHash,
    getUserOperationHash(record.operation, record.entryPoint, record.chainId)
  ))
    invalid5("The prepared operation hash differs from its contents.");
}
function sessionActionPlanInput(session, input) {
  const policy = session.compiled.reviewedPolicy;
  const index = input.actionIndex ?? 0, action = Number.isSafeInteger(index) && index >= 0 ? policy.actions?.[index] : void 0;
  if (!action || !isAddress6(action.target))
    return invalid5("Choose an exact reviewed session action.");
  const call = { chainId: session.compiled.chainId, address: action.target };
  if (action.kind === "v6-project-uri") {
    if (typeof input.uri !== "string" || !/^(ipfs:\/\/|https:\/\/)/.test(input.uri) || input.uri.length > 2048)
      invalid5("Use the pinned metadata's ipfs:// URI or an HTTPS URI.");
    return {
      account: session.compiled.wallet,
      calls: [
        {
          ...call,
          contractId: "@bananapus/core-v6:src/JBController.sol:JBController",
          projectId: action.projectId,
          function: "setUriOf(uint256,string)",
          args: [action.projectId, input.uri],
          value: "0"
        }
      ]
    };
  }
  if (!input.amount || !/^[1-9][0-9]{0,77}$/.test(input.amount) || !action.perCallLimit || BigInt(input.amount) > BigInt(action.perCallLimit))
    invalid5(
      "Enter a positive raw-unit amount within the reviewed per-call limit."
    );
  if (action.kind === "v6-pay")
    return {
      account: session.compiled.wallet,
      calls: [
        {
          ...call,
          contractId: "@bananapus/core-v6:src/JBMultiTerminal.sol:JBMultiTerminal",
          projectId: action.projectId,
          function: "pay(uint256,address,uint256,address,uint256,string,bytes)",
          args: [
            action.projectId,
            action.asset,
            input.amount,
            action.beneficiary,
            action.minReturnedTokens,
            "",
            "0x"
          ],
          value: action.asset?.toLowerCase() === "0x000000000000000000000000000000000000eeee" ? input.amount : "0"
        }
      ]
    };
  if (action.kind !== "erc20-transfer" || !input.tokenContractId || input.tokenContractId.length > 512)
    invalid5(
      "An ERC20 transfer needs its exact verified contract ID from this host's contract catalog."
    );
  return {
    account: session.compiled.wallet,
    calls: [
      {
        ...call,
        contractId: input.tokenContractId,
        function: "transfer(address,uint256)",
        args: [action.beneficiary, input.amount],
        value: "0"
      }
    ]
  };
}
function walletTypedDataDocument(document2) {
  const domainFields = [
    { name: "name", type: "string" },
    { name: "version", type: "string" },
    { name: "chainId", type: "uint256" },
    { name: "verifyingContract", type: "address" },
    { name: "salt", type: "bytes32" }
  ].filter(({ name }) => document2.domain[name] !== void 0);
  if (Object.keys(document2.domain).some(
    (name) => !domainFields.some((field) => field.name === name)
  ))
    invalid5("Unsupported signing domain field.");
  return JSON.stringify(
    { ...document2, types: { ...document2.types, EIP712Domain: domainFields } },
    (_key, value) => typeof value === "bigint" ? value.toString() : value
  );
}
async function assertWalletIdentity(provider, address3, chainId, stillCurrent = () => true) {
  if (!Number.isSafeInteger(chainId) || chainId < 1 || !isAddress6(address3))
    invalid5("Invalid wallet identity.");
  const [accounts, chain] = await Promise.all([
    provider.request({ method: "eth_accounts" }),
    provider.request({ method: "eth_chainId" })
  ]);
  if (!stillCurrent() || !Array.isArray(accounts) || !accounts.some((item) => typeof item === "string" && same(item, address3)) || typeof chain !== "string" || !/^0x[0-9a-fA-F]+$/.test(chain) || BigInt(chain) !== BigInt(chainId))
    invalid5(
      "The wallet account or chain changed. Connect again and review the request."
    );
}
async function signWalletTypedData(input) {
  await assertWalletIdentity(
    input.provider,
    input.address,
    input.chainId,
    input.stillCurrent
  );
  if (BigInt(String(input.document.domain.chainId)) !== BigInt(input.chainId))
    invalid5("The signing domain uses another chain.");
  const signature2 = await input.provider.request({
    method: "eth_signTypedData_v4",
    params: [input.address, walletTypedDataDocument(input.document)]
  });
  await assertWalletIdentity(
    input.provider,
    input.address,
    input.chainId,
    input.stillCurrent
  );
  const signaturePattern = input.signatureFormat === "wallet" ? /^0x(?:[0-9a-fA-F]{2}){1,8192}$/ : /^0x[0-9a-fA-F]{130}$/;
  if (typeof signature2 !== "string" || !signaturePattern.test(signature2))
    invalid5("The wallet returned an invalid signature.");
  return signature2;
}
function smartBindingDocument(input, now = Math.floor(Date.now() / 1e3)) {
  const { request, challenge, owner } = input;
  const state = challenge.state;
  if (!same(request.address, state.address) || state.manifestId !== request.manifestId || !state.owners.some((entry) => same(entry, owner)) || request.expiresAt <= now || request.expiresAt > now + 900 || !Number.isSafeInteger(state.threshold) || state.threshold < 1 || state.threshold > state.owners.length || !/^0x[0-9a-fA-F]{64}$/.test(state.stateHash))
    invalid5(
      "The binding challenge differs from the reviewed wallet, owners or expiration."
    );
  const document2 = {
    domain: {
      name: "Juicebox Center Smart Account",
      version: "1",
      chainId: state.chainId,
      verifyingContract: state.address,
      salt: keccak2565(
        stringToHex4(new URL(clientAudience(input.audience)).toString())
      )
    },
    types: {
      BindSmartAccount: [
        { name: "accountId", type: "string" },
        { name: "owner", type: "address" },
        { name: "stateHash", type: "bytes32" },
        { name: "nonce", type: "bytes32" },
        { name: "expiresAt", type: "uint64" }
      ]
    },
    primaryType: "BindSmartAccount",
    message: {
      accountId: input.accountId,
      owner,
      stateHash: state.stateHash,
      nonce: request.nonce,
      expiresAt: BigInt(request.expiresAt)
    }
  };
  if (!same(hashTypedData4(document2), challenge.digest))
    invalid5(
      "The binding digest differs from the locally reconstructed document."
    );
  return document2;
}
async function packOwnerSignatures(input) {
  if (!Number.isSafeInteger(input.threshold) || input.threshold < 1 || input.threshold > 16 || input.signatures.length !== input.threshold)
    invalid5("Collect exactly the wallet's current owner threshold.");
  const order = 0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141n;
  const signatures = await Promise.all(
    input.signatures.map(async (signature2) => {
      if (!/^0x[0-9a-fA-F]{130}$/.test(signature2) || !/^(1b|1c)$/i.test(signature2.slice(-2)))
        invalid5("Use direct EOA typed-data signatures with v27/28.");
      const r = BigInt(`0x${signature2.slice(2, 66)}`), s = BigInt(`0x${signature2.slice(66, 130)}`);
      if (!r || r >= order || !s || s > order / 2n)
        invalid5("Use canonical low-s owner signatures.");
      const address3 = await recoverAddress3({ hash: input.digest, signature: signature2 });
      if (!input.owners.some((owner) => same(owner, address3)))
        invalid5("A signature is not from a current wallet owner.");
      return { address: address3, signature: signature2 };
    })
  );
  signatures.sort((a, b) => BigInt(a.address) < BigInt(b.address) ? -1 : 1);
  if (new Set(signatures.map(({ address: address3 }) => address3.toLowerCase())).size !== input.threshold)
    invalid5("Owner signatures must be distinct.");
  return concatHex4(signatures.map(({ signature: signature2 }) => signature2));
}
function ownerOperationSigning(input) {
  const { record, binding: binding2 } = input;
  if (record.state !== "prepared" || record.expiresAt <= Date.now() || record.session || !same(record.accountBindingId, binding2.id) || !same(record.operation.sender, binding2.wallet.address) || !same(record.accountStateHash, binding2.state.stateHash) || record.chainId !== binding2.wallet.chainId || record.chainId !== input.chainId || !same(record.entryPoint, input.entryPoint) || !same(
    record.operationHash,
    getUserOperationHash(record.operation, record.entryPoint, record.chainId)
  ))
    invalid5(
      "The owner operation differs from the selected wallet or prepared operation."
    );
  const payload = safe7579OwnerSigningPayload({
    ...input,
    operation: record.operation
  });
  if (!same(payload.digest, record.signing.digest) || input.validAfter !== String(Math.floor(record.createdAt / 1e3)) || input.validUntil !== String(Math.floor(record.expiresAt / 1e3)))
    invalid5("The owner signing window or digest changed.");
  return payload;
}
async function ownerOperationSignature(payload, binding2, signatures) {
  const packed = await packOwnerSignatures({
    digest: payload.digest,
    owners: binding2.state.owners,
    threshold: binding2.state.threshold,
    signatures
  });
  return encodeSafe7579OwnerSignature({
    validAfter: payload.validAfter,
    validUntil: payload.validUntil,
    signatures: packed
  });
}
async function signSessionUserOperation(input) {
  const { record, session, signer } = input, c = session.compiled;
  const now = Math.floor(Date.now() / 1e3);
  if (session.state !== "active" || !record.session || record.session.id !== session.id || !same(signer.address, c.sessionKey) || !same(record.session.sessionKey, c.sessionKey) || record.session.grantId !== c.grantId || !same(record.session.compiledHash, c.compiledHash) || !same(record.session.permissionId, c.permissionId) || !same(record.accountBindingId, c.bindingId) || record.chainId !== c.chainId || !same(record.operation.sender, c.wallet) || c.validAfter > now || c.validUntil <= now || record.state !== "prepared" || record.expiresAt <= Date.now())
    invalid5(
      "This operation is not bound to the active local session key and policy."
    );
  const payload = legacySessionSigningPayload({
    operation: record.operation,
    chainId: record.chainId,
    entryPoint: record.entryPoint,
    smartSessions: c.smartSessions.address,
    permissionId: c.permissionId
  });
  if (!same(payload.operationHash, record.operationHash) || !same(payload.digest, record.signing.digest))
    invalid5("The operation hash changed before signing.");
  const signature2 = await signer.signMessage({
    message: { raw: payload.operationHash }
  });
  if (!same(
    await recoverAddress3({ hash: payload.digest, signature: signature2 }),
    signer.address
  ))
    invalid5("The session signer returned the wrong signature.");
  return encodeLegacyUseSignature(c.permissionId, signature2);
}

// src/rest/client/center.ts
import { keccak256 as keccak2566, parseTransaction, recoverTransactionAddress } from "viem";
import { privateKeyToAccount as privateKeyToAccount2 } from "viem/accounts";

// src/rest/client/connection.ts
import { isAddress as isAddress7 } from "viem";
import { privateKeyToAccount } from "viem/accounts";
function parseConnection(value) {
  const invalid8 = () => {
    throw new RestClientError("INVALID_CONNECTION", "Choose the connection file downloaded after registering your bot.");
  };
  if (!value || typeof value !== "object" || Array.isArray(value)) return invalid8();
  const v = value;
  if (Object.keys(v).some((key) => !["format", "audience", "accountId", "grantId", "botAddress", "privateKey", "scopes", "expiresAt"].includes(key)) || v.format !== "juicebox-center-connection-v1" || typeof v.audience !== "string" || typeof v.accountId !== "string" || typeof v.grantId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(v.grantId) || typeof v.botAddress !== "string" || !isAddress7(v.botAddress) || typeof v.privateKey !== "string" || !/^0x[0-9a-fA-F]{64}$/.test(v.privateKey) || !isCanonicalGrantScopes(v.scopes) || !Number.isSafeInteger(v.expiresAt) || Number(v.expiresAt) < 1) return invalid8();
  try {
    clientAudience(v.audience);
    parseAccountId(v.accountId);
    if (privateKeyToAccount(v.privateKey).address.toLowerCase() !== v.botAddress.toLowerCase()) return invalid8();
  } catch {
    return invalid8();
  }
  return {
    format: "juicebox-center-connection-v1",
    audience: v.audience,
    accountId: v.accountId,
    grantId: v.grantId,
    botAddress: v.botAddress,
    privateKey: v.privateKey,
    scopes: [...v.scopes],
    expiresAt: Number(v.expiresAt)
  };
}
function connectionForBot(audience, bot, privateKey) {
  if (bot.revokedAt !== null) throw new RestClientError("REVOKED_CONNECTION", "This bot grant has been revoked.");
  return parseConnection({
    format: "juicebox-center-connection-v1",
    audience,
    accountId: bot.accountId,
    grantId: bot.id,
    botAddress: bot.botAddress,
    privateKey,
    scopes: bot.scopes,
    expiresAt: bot.expiresAt
  });
}

// src/rest/client/center.ts
var id2 = (value) => {
  if (!/^[A-Za-z0-9._:-]{1,200}$/.test(value)) throw new RestClientError("INVALID_INPUT", "Use the identifier returned by Center.");
  return encodeURIComponent(value);
};
var CenterClient = class _CenterClient {
  constructor(options) {
    this.options = options;
    this.client = new SignedRestClient2(options);
  }
  options;
  client;
  request(options) {
    return this.client.request(options);
  }
  /** Authorizes one exact GET for a relay. Send the returned URL and headers unchanged; this method does not send it. */
  authorizeRead(requestTarget) {
    return prepareSignedRequest(this.options, { method: "GET", requestTarget });
  }
  /** Uses this connection's existing API identity and grant on every execution network. */
  smartAccounts() {
    return new SmartAccountClient(this.client);
  }
  /** Signs locally with the bot key after checking the exact plan and activated permission. Does not submit. */
  async signSessionOperation(input) {
    const reviewed = structuredClone(input), signer = this.options.signer;
    if (!this.options.grantId || reviewed.session.compiled.grantId !== this.options.grantId || reviewed.session.compiled.ownerAccountId !== this.options.accountId)
      throw new RestClientError("SESSION_CONNECTION_MISMATCH", "Use the bot connection approved for this wallet permission.");
    if (!signer.signMessage)
      throw new RestClientError("SESSION_SIGNER_REQUIRED", "The bot signer must support signing a raw message hash.");
    assertReviewedOperation(reviewed.operation, reviewed.plan);
    return signSessionUserOperation({
      record: reviewed.operation,
      session: reviewed.session,
      signer: { address: signer.address, signMessage: (value) => signer.signMessage(value) }
    });
  }
  static forOwner(options) {
    const { chainId, ...config } = options;
    return new _CenterClient({ ...config, accountId: accountIdFor(options.signer.address, chainId) });
  }
  static fromConnection(value, options = {}) {
    const connection = parseConnection(value);
    if (connection.expiresAt <= (options.now?.() ?? Math.floor(Date.now() / 1e3)))
      throw new RestClientError("CONNECTION_EXPIRED", "This bot connection expired. Register a new grant on Accounts.");
    return new _CenterClient({
      ...options,
      audience: connection.audience,
      accountId: connection.accountId,
      grantId: connection.grantId,
      signer: privateKeyToAccount2(connection.privateKey)
    });
  }
  account() {
    return this.request({ requestTarget: "/api/v1/accounts/me" });
  }
  enroll() {
    return this.request({ method: "POST", requestTarget: "/api/v1/accounts/enroll", json: {} });
  }
  bots() {
    return this.request({ requestTarget: "/api/v1/accounts/me/bots" });
  }
  revokeBot(grantId) {
    return this.request({ method: "DELETE", requestTarget: `/api/v1/accounts/me/bots/${id2(grantId)}` });
  }
  async registerBot(input) {
    const proof = await createBotRegistration(this.options.audience, {
      accountId: this.options.accountId,
      botAddress: input.signer.address,
      scopes: input.scopes,
      label: input.label,
      expiresAt: input.expiresAt,
      ownerRequestNonce: newRequestNonce()
    }, input.signer);
    const { bot } = await this.request({ method: "POST", requestTarget: "/api/v1/accounts/me/bots", json: proof.registration, nonce: proof.ownerRequestNonce });
    if (bot.accountId !== this.options.accountId || bot.botAddress.toLowerCase() !== input.signer.address.toLowerCase() || bot.expiresAt !== input.expiresAt || bot.revokedAt !== null || JSON.stringify(bot.scopes) !== JSON.stringify(input.scopes))
      throw new RestClientError("INVALID_RESPONSE", "Registration did not match the requested API access.");
    return { bot, client: new _CenterClient({ ...this.options, signer: input.signer, grantId: bot.id }) };
  }
  capabilities() {
    return readPublicRestJson(this.options.audience, "/api/v1/capabilities", this.options.fetch);
  }
  prepare(input, idempotencyKey) {
    return this.request({ method: "POST", requestTarget: "/api/v1/plans", json: input, idempotencyKey });
  }
  plan(planId, options = {}) {
    return this.request({ requestTarget: `/api/v1/plans/${id2(planId)}${options.refresh ? "?refresh=true" : ""}` });
  }
  simulate(planId, stepIndex) {
    this.step(stepIndex);
    return this.request({ requestTarget: `/api/v1/plans/${id2(planId)}/steps/${stepIndex}/simulation` });
  }
  /** Call after the owner reviews the plan and the transaction wallet signs the exact bytes. */
  async approveTransaction(input, owner) {
    this.step(input.stepIndex);
    if (!input.plan.draft.calls[input.stepIndex] || input.plan.expiresAt <= (this.options.now?.() ?? Math.floor(Date.now() / 1e3)) * 1e3)
      throw new RestClientError("PLAN_NOT_READY", "Review a current plan and choose one of its steps.");
    input = structuredClone(input);
    const call = input.plan.draft.calls[input.stepIndex];
    try {
      const transaction = parseTransaction(input.rawSignedTransaction);
      const sender = await recoverTransactionAddress({ serializedTransaction: input.rawSignedTransaction });
      if (transaction.chainId !== call.chainId || transaction.to?.toLowerCase() !== call.to.toLowerCase() || (transaction.data ?? "0x").toLowerCase() !== call.data.toLowerCase() || (transaction.value ?? 0n) !== BigInt(call.value) || sender.toLowerCase() !== input.plan.account.toLowerCase() || !["legacy", "eip2930", "eip1559"].includes(transaction.type ?? "legacy")) throw new Error("Mismatch");
    } catch {
      throw new RestClientError("SIGNED_TRANSACTION_MISMATCH", "The wallet-signed transaction does not match this reviewed plan step.");
    }
    const result = { planId: input.plan.id, stepIndex: input.stepIndex, rawSignedTransaction: input.rawSignedTransaction };
    if (!this.options.grantId) return result;
    const claims2 = {
      ...this.approvalWindow(owner),
      planId: input.plan.id,
      commitment: input.plan.commitment,
      stepIndex: input.stepIndex,
      transactionHash: keccak2566(input.rawSignedTransaction)
    };
    return { ...result, ownerApproval: { ...claims2, signature: await owner.signTypedData(buildTransactionApprovalTypedData(this.options.audience, claims2)) } };
  }
  submitTransaction(input, idempotencyKey) {
    this.step(input.stepIndex);
    const { planId, stepIndex, ...json } = input;
    return this.request({ method: "POST", requestTarget: `/api/v1/plans/${id2(planId)}/steps/${stepIndex}/submissions`, json, idempotencyKey });
  }
  preparePrepaid(planId, stepIndexes, idempotencyKey) {
    return this.request({ method: "POST", requestTarget: "/api/v1/sponsorships", json: { planId, ...stepIndexes ? { stepIndexes } : {} }, idempotencyKey });
  }
  prepaid(sponsorshipId, options = {}) {
    return this.request({ requestTarget: `/api/v1/sponsorships/${id2(sponsorshipId)}${options.refresh ? "?refresh=true" : ""}` });
  }
  async approvePrepaid(preparation, signatures, owner) {
    if (signatures.length !== preparation.authorizations.length || preparation.publicationExpiresAt <= (this.options.now?.() ?? Math.floor(Date.now() / 1e3)) * 1e3)
      throw new RestClientError("PLAN_NOT_READY", "Review a current preparation and sign each returned authorization in order.");
    const result = { sponsorshipId: preparation.id, signatures: [...signatures] };
    if (!this.options.grantId) return result;
    const claims2 = {
      ...this.approvalWindow(owner),
      sponsorshipId: preparation.id,
      commitment: preparation.commitment,
      submissionHash: sponsorshipSubmissionHash(preparation.commitment, signatures)
    };
    return { ...result, ownerApproval: { ...claims2, signature: await owner.signTypedData(buildSponsorshipApprovalTypedData(this.options.audience, claims2)) } };
  }
  submitPrepaid(input, idempotencyKey) {
    const { sponsorshipId, ...json } = input;
    return this.request({ method: "POST", requestTarget: `/api/v1/sponsorships/${id2(sponsorshipId)}/submissions`, json, idempotencyKey });
  }
  prepareFunding(sponsorshipId, chainId, payer, idempotencyKey) {
    return this.request({ method: "POST", requestTarget: `/api/v1/sponsorships/${id2(sponsorshipId)}/funding-plans`, json: { chainId, payer }, idempotencyKey });
  }
  step(index) {
    if (!Number.isInteger(index) || index < 0 || index > 31) throw new RestClientError("INVALID_INPUT", "Choose a plan step from 0 through 31.");
  }
  approvalWindow(owner) {
    if (parseAccountId(this.options.accountId).ownerAddress.toLowerCase() !== owner.address.toLowerCase())
      throw new RestClientError("OWNER_MISMATCH", "The account owner must approve this submission.");
    const issuedAt = this.options.now?.() ?? Math.floor(Date.now() / 1e3);
    return { accountId: this.options.accountId, principalId: `bot:${this.options.grantId}`, issuedAt, expiresAt: issuedAt + 300, nonce: newRequestNonce() };
  }
};

// src/rest/client/wallet.ts
import { toHex as toHex7 } from "viem";
import { generatePrivateKey, privateKeyToAccount as privateKeyToAccount3 } from "viem/accounts";

// src/rest/client/walletPayments.ts
import { sha256 as sha2564, stringToHex as stringToHex6 } from "viem";

// src/rest/smartAccounts/passkeySignatures.ts
import {
  concatHex as concatHex5,
  getAddress as getAddress5,
  hashDomain,
  hashStruct,
  hashTypedData as hashTypedData5,
  keccak256 as keccak2567,
  recoverAddress as recoverAddress4,
  size as size2,
  sliceHex as sliceHex3,
  toHex as toHex5,
  zeroAddress as zeroAddress2
} from "viem";
var MAX_PACKED_BYTES = 8192 - 20;
var MAX_CONTRACT_BYTES = 4096;
var MAX_OWNERS = 16;
function fail2(message2) {
  throw new RestError(400, "SMART_ACCOUNT_ENVELOPE_INVALID", message2);
}
function bytes(value, label, minimum, maximum) {
  if (typeof value !== "string" || !/^0x(?:[0-9a-fA-F]{2})*$/.test(value) || (value.length - 2) / 2 < minimum || (value.length - 2) / 2 > maximum)
    fail2(`${label} must contain ${minimum} to ${maximum} complete bytes.`);
  return value.toLowerCase();
}
function thresholdChecked(threshold) {
  if (!Number.isInteger(threshold) || threshold < 1 || threshold > MAX_OWNERS)
    fail2("Supply a current owner threshold between 1 and 16.");
}
function validityPrefix(input) {
  const after = integer(input.validAfter, "validAfter", false, 48);
  const until = integer(input.validUntil, "validUntil", false, 48);
  if (until <= after) fail2("Owner operations require a finite ordered validity interval.");
  return concatHex5([toHex5(after, { size: 6 }), toHex5(until, { size: 6 })]);
}
function ecdsaChecked(value) {
  const signature2 = bytes(value, "ECDSA signature", 65, 65);
  return canonicalEoaSignature(signature2);
}
function decodeSafeOwnerSignatures(value, threshold) {
  thresholdChecked(threshold);
  const data = bytes(value, "packed owner signatures", 65 * threshold, MAX_PACKED_BYTES);
  let dynamicOffset = 65 * threshold;
  const result = [];
  for (let i = 0; i < threshold; i++) {
    const entry = sliceHex3(data, i * 65, (i + 1) * 65);
    const v = Number(BigInt(sliceHex3(entry, 64, 65)));
    if (v !== 0) {
      result.push({ kind: "ecdsa", signature: ecdsaChecked(entry) });
      continue;
    }
    const ownerWord = BigInt(sliceHex3(entry, 0, 32));
    if (ownerWord === 0n || ownerWord >> 160n) fail2("Contract owner address must use canonical zero padding.");
    const offset = BigInt(sliceHex3(entry, 32, 64));
    if (offset !== BigInt(dynamicOffset) || dynamicOffset + 32 > size2(data))
      fail2("Contract signature offsets must follow the static table without gaps, aliases or overlap.");
    const length = BigInt(sliceHex3(data, dynamicOffset, dynamicOffset + 32));
    if (length < 1n || length > BigInt(MAX_CONTRACT_BYTES) || BigInt(dynamicOffset + 32) + length > BigInt(size2(data)))
      fail2("Contract signature length is outside the bounded envelope.");
    result.push({
      kind: "contract",
      owner: getAddress5(toHex5(ownerWord, { size: 20 })),
      signature: sliceHex3(data, dynamicOffset + 32, dynamicOffset + 32 + Number(length))
    });
    dynamicOffset += 32 + Number(length);
  }
  if (dynamicOffset !== size2(data)) fail2("Owner signatures cannot contain trailing bytes or extra entries.");
  return result;
}
function decodeSafe7579PasskeyOwnerSignature(input) {
  const signature2 = bytes(input.signature, "SafeOp owner envelope", 77, 12 + MAX_PACKED_BYTES);
  if (sliceHex3(signature2, 0, 12) !== validityPrefix(input))
    fail2("Owner signature validity differs from its review.");
  return decodeSafeOwnerSignatures(sliceHex3(signature2, 12), input.threshold);
}
function safe7579PasskeyOwnerSigningPayload(input) {
  const payload = safe7579OwnerSigningPayload(input);
  const original = payload.typedData;
  const typedData = {
    ...original,
    domain: { ...original.domain, chainId: BigInt(original.domain.chainId) },
    message: {
      ...original.message,
      nonce: BigInt(original.message.nonce),
      verificationGasLimit: BigInt(original.message.verificationGasLimit),
      callGasLimit: BigInt(original.message.callGasLimit),
      preVerificationGas: BigInt(original.message.preVerificationGas),
      maxPriorityFeePerGas: BigInt(original.message.maxPriorityFeePerGas),
      maxFeePerGas: BigInt(original.message.maxFeePerGas),
      validAfter: Number(original.message.validAfter),
      validUntil: Number(original.message.validUntil)
    }
  };
  const signedData = concatHex5([
    "0x1901",
    hashDomain({ domain: { ...typedData.domain, chainId: BigInt(input.chainId) }, types: typedData.types }),
    hashStruct({ data: typedData.message, primaryType: typedData.primaryType, types: typedData.types })
  ]);
  if (keccak2567(signedData) !== payload.digest) fail2("SafeOp preimage differs from its approved digest.");
  return { ...payload, signedData };
}

// src/rest/userOperations/semantics.ts
import { decodeEventLog, decodeFunctionData as decodeFunctionData3, encodeAbiParameters as encodeAbiParameters5, encodeEventTopics, encodeFunctionData as encodeFunctionData3, erc20Abi, getAddress as getAddress6, isAddress as isAddress8, parseAbi as parseAbi3, zeroAddress as zeroAddress3 } from "viem";
var terminalAbi = parseAbi3([
  "function pay(uint256 projectId,address token,uint256 amount,address beneficiary,uint256 minReturnedTokens,string memo,bytes metadata) payable returns(uint256)",
  "event Pay(uint256 indexed rulesetId,uint256 indexed rulesetCycleNumber,uint256 indexed projectId,address payer,address beneficiary,uint256 amount,uint256 newlyIssuedTokenCount,string memo,bytes metadata,address caller)"
]);
var same2 = (a, b) => a.toLowerCase() === b.toLowerCase();
var bytes2 = (v, max = 32768) => typeof v === "string" && v.length <= 2 + max * 2 && /^0x(?:[0-9a-fA-F]{2})*$/.test(v);
var address2 = (v) => {
  if (typeof v !== "string" || !isAddress8(v) || same2(v, zeroAddress3)) throw new Error("address");
  return getAddress6(v);
};
var object = (v) => {
  if (!v || typeof v !== "object" || Array.isArray(v) || ![Object.prototype, null].includes(Object.getPrototypeOf(v))) throw new Error("object");
  return v;
};
function snapshot(input, maxBytes) {
  let nodes = 0, serializedBytes = 0;
  const count = (text) => {
    serializedBytes += new TextEncoder().encode(text).length;
    if (serializedBytes > maxBytes) throw new Error("bound");
  };
  const copy = (v, depth) => {
    if (++nodes > 3e4 || depth > 20) throw new Error("bound");
    if (v === null || typeof v === "boolean") {
      count(String(v));
      return v;
    }
    if (typeof v === "string") {
      if (v.length > maxBytes) throw new Error("bound");
      count(JSON.stringify(v));
      return v;
    }
    if (typeof v === "number" && Number.isSafeInteger(v)) {
      count(String(v));
      return v;
    }
    if (typeof v === "bigint" && v >= 0n && v < 2n ** 256n) {
      count(JSON.stringify(String(v)));
      return String(v);
    }
    if (!v || typeof v !== "object") throw new Error("data");
    const array = Array.isArray(v);
    if (!array) object(v);
    if (Object.getOwnPropertySymbols(v).length) throw new Error("symbol");
    const descriptors = Object.getOwnPropertyDescriptors(v);
    const entries = Object.entries(descriptors);
    if (entries.length > 3e4) throw new Error("bound");
    if (array) {
      const length = descriptors.length;
      if (!length || !("value" in length) || !Number.isSafeInteger(length.value) || length.value > 3e4 || length.value !== entries.length - 1) throw new Error("array bound");
      for (let i = 0; i < length.value; i++) if (!Object.hasOwn(descriptors, String(i))) throw new Error("sparse array");
    }
    count("[]");
    const out = array ? [] : /* @__PURE__ */ Object.create(null);
    for (const [key, desc] of entries) {
      if (array && key === "length") continue;
      if (!desc.enumerable || !("value" in desc) || array && !/^(?:0|[1-9][0-9]*)$/.test(key)) throw new Error("descriptor");
      count(array ? "," : `${JSON.stringify(key)}:,`);
      Object.defineProperty(out, key, { value: copy(desc.value, depth + 1), enumerable: true, configurable: true, writable: true });
    }
    return out;
  };
  const result = copy(input, 0);
  if (new TextEncoder().encode(JSON.stringify(result)).length > maxBytes) throw new Error("bound");
  return result;
}
function uint(v) {
  if (typeof v === "number" && Number.isSafeInteger(v) && v >= 0) return BigInt(v);
  if (typeof v === "string" && v.length <= 78 && /^(?:0|[1-9][0-9]*|0x(?:0|[1-9a-fA-F][0-9a-fA-F]*))$/.test(v)) {
    const n = BigInt(v);
    if (n < 2n ** 256n) return n;
  }
  throw new Error("quantity");
}
function recognizeWalletV6UsdcPayment(plan, stepIndexes, config) {
  try {
    const { draft } = snapshot(plan, 262144);
    const indexes = snapshot(stepIndexes, 128);
    const trusted = snapshot(config, 1024);
    if (trusted.chainId !== 8453 || draft.operation !== "pay") return null;
    const token = address2(trusted.token), terminal = address2(trusted.directV6Terminal), account = address2(draft.account);
    if (same2(token, terminal) || same2(account, terminal) || same2(account, token)) return null;
    const calls = draft.calls;
    if (!Array.isArray(calls) || calls.length < 1 || calls.length > 3 || !Array.isArray(indexes) || indexes.length !== calls.length || indexes.some((v, i) => v !== i)) return null;
    const project = object(draft.project);
    if (project.chainId !== 8453 || project.version !== void 0 && project.version !== 6 || typeof project.projectId !== "string" || !/^[1-9][0-9]*$/.test(project.projectId)) return null;
    const projectId = uint(project.projectId);
    for (const [i, call] of calls.entries()) {
      if (call.chainId !== 8453 || call.value !== "0" || !bytes2(call.data) || !Array.isArray(call.dependsOn) || call.dependsOn.length !== (i === 0 ? 0 : 1) || i > 0 && call.dependsOn[0] !== i - 1) return null;
    }
    const last = calls[calls.length - 1];
    if (!same2(address2(last.to), terminal)) return null;
    const decoded = decodeFunctionData3({ abi: terminalAbi, data: last.data });
    if (decoded.functionName !== "pay" || !same2(encodeFunctionData3({ abi: terminalAbi, functionName: "pay", args: decoded.args }), last.data)) return null;
    const [id3, paidToken, amount, to, minimum, memo, metadata] = decoded.args;
    if (id3 !== projectId || !same2(paidToken, token) || amount <= 0n || amount === 2n ** 256n - 1n || !bytes2(metadata, 16384) || new TextEncoder().encode(memo).length > 256) return null;
    const beneficiary = address2(to);
    for (let i = 0; i < calls.length - 1; i++) {
      const call = calls[i];
      if (!same2(address2(call.to), token)) return null;
      const approval = decodeFunctionData3({ abi: erc20Abi, data: call.data });
      if (approval.functionName !== "approve" || !same2(approval.args[0], terminal) || approval.args[1] !== (calls.length === 3 && i === 0 ? 0n : amount) || !same2(encodeFunctionData3({ abi: erc20Abi, functionName: "approve", args: approval.args }), call.data)) return null;
    }
    const summary = object(draft.summary), payment = object(summary.payment), quotedProject = object(summary.project);
    if (summary.operation !== "pay" || !same2(address2(summary.account), account) || summary.route !== "multi-terminal" || !same2(address2(summary.terminal), terminal) || summary.routerGateway !== null || !Array.isArray(summary.terminalPath) || summary.terminalPath.length !== 1 || !same2(address2(summary.terminalPath[0]), terminal) || quotedProject.chainId !== 8453 || quotedProject.projectId !== project.projectId || quotedProject.version !== void 0 && quotedProject.version !== 6 || !same2(address2(payment.token), token) || payment.amount !== String(amount) || payment.unit !== "token-base-units" || !same2(address2(summary.beneficiary), beneficiary) || summary.minimumBeneficiaryTokenCount !== String(minimum) || typeof summary.metadata !== "string" || !same2(summary.metadata, metadata)) return null;
    return Object.freeze({
      kind: "v6-usdc-pay",
      chainId: 8453,
      account,
      token,
      terminal,
      projectId: String(id3),
      amount: String(amount),
      beneficiary,
      minimumReturnedTokens: String(minimum),
      memo,
      metadata,
      stepIndexes: Object.freeze([...indexes]),
      approvalStepIndexes: Object.freeze(indexes.slice(0, -1)),
      paymentStepIndex: calls.length - 1,
      resetAllowance: calls.length === 3
    });
  } catch {
    return null;
  }
}

// src/rest/wallet/sharedHandoff.ts
import { hashTypedData as hashTypedData6, hexToBytes, keccak256 as keccak2568, sha256 as sha2563, stringToHex as stringToHex5, toHex as toHex6 } from "viem";
var requestMessageTypes = [
  { name: "version", type: "string" },
  { name: "issuer", type: "string" },
  { name: "origin", type: "string" },
  { name: "callbackUri", type: "string" },
  { name: "audience", type: "string" },
  { name: "appGeneration", type: "uint64" },
  { name: "requestKey", type: "address" },
  { name: "state", type: "bytes32" },
  { name: "codeChallenge", type: "bytes32" },
  { name: "nonce", type: "bytes32" },
  { name: "issuedAtMs", type: "uint64" },
  { name: "expiresAtMs", type: "uint64" }
];
var exchangeMessageTypes = [
  ...requestMessageTypes,
  { name: "intentId", type: "bytes32" },
  { name: "codeHash", type: "bytes32" }
];
for (const field of exchangeMessageTypes) Object.freeze(field);
var requestTypes2 = Object.freeze({ WalletHandoffRequest: Object.freeze(requestMessageTypes) });
var exchangeTypes = Object.freeze({ WalletHandoffExchange: Object.freeze(exchangeMessageTypes) });
var launchTypes = Object.freeze({ WalletHandoffLaunch: Object.freeze([
  Object.freeze({ name: "intentId", type: "bytes32" }),
  Object.freeze({ name: "requestDigest", type: "bytes32" })
]) });
function base64url(bytes3) {
  return btoa(String.fromCharCode(...bytes3)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function validateWalletHandoffToken(value) {
  if (typeof value !== "string" || value.length !== 43 || !/^[A-Za-z0-9_-]{43}$/.test(value)) throw new Error("Invalid wallet handoff token.");
  const bytes3 = Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/") + "="), (character) => character.charCodeAt(0));
  if (bytes3.length !== 32 || base64url(bytes3) !== value) throw new Error("Invalid wallet handoff token.");
  return value;
}
function tokenHex(value) {
  return toHex6(Uint8Array.from(atob(validateWalletHandoffToken(value).replaceAll("-", "+").replaceAll("_", "/") + "="), (character) => character.charCodeAt(0)));
}
function walletHandoffPkceChallenge(value) {
  if (typeof value !== "string" || value.length < 43 || value.length > 128 || !/^[A-Za-z0-9._~-]+$/.test(value)) throw new Error("Invalid wallet handoff verifier.");
  return base64url(hexToBytes(sha2563(stringToHex5(value))));
}
function walletHandoffCodeHash(value) {
  return sha2563(stringToHex5("center-wallet-handoff-code-v1\0" + validateWalletHandoffToken(value)));
}
function domain2(request) {
  return { name: "Juicebox Center Wallet Handoff", version: "1", chainId: 8453, salt: keccak2568(stringToHex5(request.issuer)) };
}
function message(request) {
  return {
    ...request,
    state: tokenHex(request.state),
    codeChallenge: tokenHex(request.codeChallenge),
    appGeneration: BigInt(request.appGeneration),
    issuedAtMs: BigInt(request.issuedAtMs),
    expiresAtMs: BigInt(request.expiresAtMs)
  };
}
function walletHandoffRequestDocument(request) {
  return { domain: domain2(request), types: requestTypes2, primaryType: "WalletHandoffRequest", message: message(request) };
}
function walletHandoffExchangeDocument(input) {
  return {
    domain: domain2(input.request),
    types: exchangeTypes,
    primaryType: "WalletHandoffExchange",
    message: { ...message(input.request), intentId: tokenHex(input.intentId), codeHash: input.codeHash }
  };
}
function walletHandoffLaunchDocument(input) {
  return {
    domain: domain2(input.request),
    types: launchTypes,
    primaryType: "WalletHandoffLaunch",
    message: { intentId: tokenHex(input.intentId), requestDigest: hashTypedData6(walletHandoffRequestDocument(input.request)) }
  };
}

// src/rest/client/walletPayments.ts
var maximumBytes = 1048576;
var reviewPath = "/api/v1/wallet/payment-reviews";
var paymentFields = ["kind", "chainId", "account", "token", "terminal", "projectId", "amount", "beneficiary", "minimumReturnedTokens", "memo", "metadata"];
var states = ["reviewing", "approved", "submitting", "pending", "confirming", "paid", "reverted", "cancelled", "unknown"];
var hex32 = (value) => typeof value === "string" && /^0x[0-9a-fA-F]{64}$/.test(value);
var uuid2 = (value) => typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(value);
var integer2 = (value) => typeof value === "number" && Number.isSafeInteger(value) && value > 0;
var same3 = (a, b) => typeof a === "string" && typeof b === "string" && a.toLowerCase() === b.toLowerCase();
var equal = (a, b) => uoCanonical(a) === uoCanonical(b);
function fail3(code, message2) {
  throw new RestClientError(code, message2);
}
function mismatch() {
  return fail3("WALLET_PAYMENT_MISMATCH", "The payment differs from this app\u2019s exact reviewed operation.");
}
function snapshot2(value) {
  const encoded = JSON.stringify(value);
  if (encoded === void 0 || new TextEncoder().encode(encoded).length > maximumBytes) mismatch();
  return JSON.parse(encoded);
}
function fields(value, required2, optional2 = []) {
  if (!value || typeof value !== "object" || Array.isArray(value)) mismatch();
  const keys = Object.keys(value);
  if (required2.some((key) => !keys.includes(key)) || keys.some((key) => !required2.includes(key) && !optional2.includes(key))) mismatch();
  return value;
}
function comparablePayment(payment) {
  return Object.fromEntries(Object.entries(payment).map(([key, value]) => [
    key,
    ["account", "token", "terminal", "beneficiary", "metadata"].includes(key) && typeof value === "string" ? value.toLowerCase() : value
  ]));
}
function createCenterWalletPaymentClient(options) {
  const { issuer, audience, callbackUri, storage, location, now } = options;
  const key = "center.wallet.payment.v1:" + issuer + ":" + callbackUri, historyKey = key + ":history";
  function raw(name = key) {
    try {
      return storage.getItem(name);
    } catch {
      return fail3("WALLET_PAYMENT_STORAGE_UNAVAILABLE", "This tab could not read its payment record.");
    }
  }
  function save(value, expected) {
    const copy = snapshot2(value), integrity = sha2564(stringToHex6(uoCanonical(copy))), encoded = JSON.stringify({ ...copy, integrity });
    if (raw() !== expected) fail3("WALLET_PAYMENT_CHANGED", "This tab changed its pending payment. Resume the current payment.");
    try {
      if (new TextEncoder().encode(encoded).length > maximumBytes) throw new Error();
      storage.setItem(key, encoded);
      if (storage.getItem(key) !== encoded) throw new Error();
    } catch {
      return fail3("WALLET_PAYMENT_STORAGE_UNAVAILABLE", "This tab could not preserve its payment before continuing.");
    }
    return { value: copy, encoded };
  }
  function checkInput(input, grant, at) {
    try {
      const operation = input.operation, expected = input.expectedPayment;
      assertReviewedOperation(operation, input.plan, at);
      if (operation.chainId !== 8453 || grant.accountId !== "eip155:8453:" + operation.operation.sender.toLowerCase() || operation.session || operation.submission || operation.observation || input.plan.expiresAt <= at || !hex32(operation.commitment) || !integer2(at) || !("ownerProfile" in operation.signing) || operation.signing.ownerProfile !== "center-passkey-v1") mismatch();
      const signing = operation.signing;
      const derived = safe7579PasskeyOwnerSigningPayload({
        operation: operation.operation,
        chainId: 8453,
        entryPoint: operation.entryPoint,
        safe7579: signing.typedData.domain.verifyingContract,
        validAfter: signing.validAfter,
        validUntil: signing.validUntil
      });
      if (!equal(signing, { ...derived, ownerProfile: "center-passkey-v1" })) mismatch();
      const payment = recognizeWalletV6UsdcPayment(
        input.plan,
        operation.stepIndexes,
        { chainId: 8453, token: expected.token, directV6Terminal: expected.terminal }
      );
      if (!payment || paymentFields.some((field) => {
        const actual = payment[field], wanted = expected[field];
        return ["account", "token", "terminal", "beneficiary", "metadata"].includes(field) ? !same3(actual, wanted) : actual !== wanted;
      }) || typeof expected.maximumNetworkFee !== "string" || !/^[1-9][0-9]{0,77}$/.test(expected.maximumNetworkFee) || BigInt(expected.maximumNetworkFee) >= 2n ** 256n || userOperationMaximumCost(operation.operation) > BigInt(expected.maximumNetworkFee)) mismatch();
      return payment;
    } catch {
      return mismatch();
    }
  }
  function live(value) {
    let current;
    try {
      current = options.connection();
    } catch {
      current = null;
    }
    if (!current || current.grant.revokedAt !== null || current.grant.expiresAt <= Math.floor(now() / 1e3) || current.grant.audience !== audience || current.grant.callbackUri !== callbackUri || value && !equal(current.grant, value.grant))
      fail3("WALLET_PAYMENT_CONNECTION_CHANGED", "Reconnect the original app grant to continue this pending payment.");
    return current;
  }
  function checkApproval(value, saved) {
    const approval = fields(value, ["signature", "signedCommitment"]);
    if (typeof approval.signature !== "string" || !/^0x(?:[0-9a-fA-F]{2}){77,8192}$/.test(approval.signature) || !hex32(approval.signedCommitment)) mismatch();
    const signing = saved.operation.signing;
    if (!("ownerProfile" in signing)) mismatch();
    const entries = decodeSafe7579PasskeyOwnerSignature({
      signature: approval.signature,
      validAfter: signing.validAfter,
      validUntil: signing.validUntil,
      threshold: 1
    });
    if (entries.length !== 1 || entries[0]?.kind !== "contract" || !same3(
      approval.signedCommitment,
      userOperationCommitment({ ...saved.operation.operation, signature: approval.signature }, saved.operation.entryPoint, 8453)
    )) mismatch();
    return { signature: approval.signature, signedCommitment: approval.signedCommitment };
  }
  function checkView(input, saved, appView) {
    try {
      const value = snapshot2(input);
      const v = fields(value, [
        "version",
        "id",
        "state",
        "issuer",
        "accountId",
        "app",
        "planId",
        "planCommitment",
        "operationId",
        "operationCommitment",
        "operationHash",
        "stepIndexes",
        "operation",
        "chainId",
        "entryPoint",
        "safe7579",
        "payment",
        "signing",
        "createdAtMs",
        "expiresAtMs",
        "status",
        "approvedAtMs",
        "cancelledAtMs",
        "operationState",
        ...appView ? ["approval"] : []
      ]);
      const app = fields(v.app, ["origin", "callbackUri", "grantId", "grantIncarnation"]);
      const signing = saved.operation.signing;
      if (!("ownerProfile" in signing)) mismatch();
      const expectedSigning = { digest: signing.digest, signedData: signing.signedData, validAfter: signing.validAfter, validUntil: signing.validUntil };
      const payment = checkInput(saved, saved.grant, saved.startedAtMs);
      if (v.version !== "center-wallet-payment-review-v1" || !uuid2(v.id) || saved.review && v.id !== saved.review.id || v.state !== saved.state || v.issuer !== issuer || v.accountId !== saved.grant.accountId || app.origin !== saved.grant.origin || app.callbackUri !== callbackUri || app.grantId !== saved.grant.id || app.grantIncarnation !== saved.grant.incarnation || v.planId !== saved.plan.id || !same3(v.planCommitment, saved.plan.commitment) || v.operationId !== saved.operation.id || !same3(v.operationCommitment, saved.operation.commitment) || !same3(v.operationHash, saved.operation.operationHash) || !equal(v.stepIndexes, saved.operation.stepIndexes) || !equal(normalizeUserOperation(v.operation), normalizeUserOperation(saved.operation.operation)) || v.chainId !== 8453 || !same3(v.entryPoint, saved.operation.entryPoint) || !same3(v.safe7579, signing.typedData.domain.verifyingContract) || !equal(v.signing, expectedSigning) || !equal(comparablePayment(v.payment), comparablePayment(payment)) || !integer2(v.createdAtMs) || v.createdAtMs < saved.startedAtMs - 3e4 || v.createdAtMs > now() + 3e4 || !integer2(v.expiresAtMs) || v.expiresAtMs <= v.createdAtMs || v.expiresAtMs > saved.operation.expiresAt || v.expiresAtMs > saved.grant.expiresAt * 1e3 || v.expiresAtMs > v.createdAtMs + 3e5 || saved.review && (v.createdAtMs !== saved.review.createdAtMs || v.expiresAtMs !== saved.review.expiresAtMs) || !["pending", "approved", "cancelled"].includes(String(v.status)) || !["prepared", "submitting", "submission_unknown", "pending", "unknown", "confirming", "confirmed", "reverted"].includes(String(v.operationState))) mismatch();
      if (v.status === "approved" ? !integer2(v.approvedAtMs) || v.cancelledAtMs !== null : v.approvedAtMs !== null) mismatch();
      if (v.status === "cancelled" ? !integer2(v.cancelledAtMs) : v.cancelledAtMs !== null) mismatch();
      for (const at of [v.approvedAtMs, v.cancelledAtMs])
        if (at !== null && (!integer2(at) || at < v.createdAtMs || at > v.expiresAtMs || at > now() + 3e4)) mismatch();
      if (appView) {
        if (v.status === "approved") checkApproval(v.approval, saved);
        else if (v.approval !== null) mismatch();
      }
      if (saved.approval && (v.status !== "approved" || appView && !equal(v.approval, saved.approval))) mismatch();
      return value;
    } catch {
      return mismatch();
    }
  }
  function read() {
    const encoded = raw();
    if (encoded === null) return null;
    try {
      if (new TextEncoder().encode(encoded).length > maximumBytes) throw new Error();
      const decoded = JSON.parse(encoded), { integrity, ...value } = decoded;
      if (integrity !== sha2564(stringToHex6(uoCanonical(value))) || value.version !== "center-wallet-payment-client-v1" || value.issuer !== issuer || value.audience !== audience || value.callbackUri !== callbackUri || !states.includes(value.status) || typeof value.submissionStarted !== "boolean" || !/^payment-review-[0-9a-f]{64}$/.test(value.reviewKey) || !/^payment-submit-[0-9a-f]{64}$/.test(value.submissionKey)) throw new Error();
      validateWalletHandoffToken(value.state);
      checkInput(value, value.grant, value.startedAtMs);
      if (value.review) checkView(value.review, value, false);
      if (value.approval) checkApproval(value.approval, value);
      if (value.submissionStarted && !value.approval) throw new Error();
      return { value, encoded };
    } catch {
      return fail3("WALLET_PAYMENT_STORAGE_INVALID", "The saved payment record is invalid. Preserve it for recovery.");
    }
  }
  function pending() {
    const value = read();
    if (!value) fail3("WALLET_PAYMENT_MISSING", "There is no pending payment in this tab.");
    return value;
  }
  function status(value) {
    return snapshot2({
      status: value.status,
      accountId: value.grant.accountId,
      chainId: 8453,
      operationId: value.operation.id,
      operationHash: value.operation.operationHash,
      reviewId: value.review?.id ?? null,
      approvalUrl: value.review ? issuer + "/wallet/payment?review=" + value.review.id : null,
      expiresAtMs: value.review?.expiresAtMs ?? value.operation.expiresAt,
      expectedPayment: value.expectedPayment,
      ...value.observation ? {
        observation: value.observation,
        ...hex32(value.observation.transactionHash) ? { transactionHash: value.observation.transactionHash } : {}
      } : {}
    });
  }
  function receiveView(input, saved, appView) {
    const reviewed = checkView(input, saved.value, appView);
    const { approval, ...review } = reviewed;
    const state = saved.value.submissionStarted ? saved.value.status : reviewed.status === "approved" ? "approved" : reviewed.status === "cancelled" ? "cancelled" : "reviewing";
    return save({ ...saved.value, review, status: state, ...approval ? { approval } : {} }, saved.encoded);
  }
  async function requestReview(saved) {
    const client = live(saved.value).client;
    const value = await client.request({
      method: "POST",
      requestTarget: reviewPath,
      json: { operationId: saved.value.operation.id, state: saved.value.state },
      idempotencyKey: saved.value.reviewKey
    });
    return receiveView(value, saved, false);
  }
  async function preparePayment(input) {
    const existing = read();
    if (existing) {
      checkInput(snapshot2(input), existing.value.grant, existing.value.startedAtMs);
      if (input.expectedPayment.maximumNetworkFee !== existing.value.expectedPayment.maximumNetworkFee) mismatch();
      if (!equal(existing.value.plan, snapshot2(input.plan)) || !equal(existing.value.operation, snapshot2(input.operation)))
        fail3("WALLET_PAYMENT_PENDING", "Resolve this tab\u2019s existing payment before preparing another operation.");
      live(existing.value);
      if (existing.value.review) return status(existing.value);
      return status((await requestReview(existing)).value);
    }
    const current = live(), copy = snapshot2(input), startedAtMs = now();
    const payment = checkInput(copy, current.grant, startedAtMs);
    const expectedPayment = { ...Object.fromEntries(paymentFields.map((field) => [field, payment[field]])), maximumNetworkFee: copy.expectedPayment.maximumNetworkFee };
    const bytes3 = crypto.getRandomValues(new Uint8Array(32));
    const state = btoa(String.fromCharCode(...bytes3)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
    const value = {
      ...copy,
      expectedPayment,
      version: "center-wallet-payment-client-v1",
      issuer,
      audience,
      callbackUri,
      grant: snapshot2(current.grant),
      startedAtMs,
      state,
      reviewKey: "payment-review-" + newRequestNonce().slice(2),
      submissionKey: "payment-submit-" + newRequestNonce().slice(2),
      submissionStarted: false,
      status: "reviewing"
    };
    return status((await requestReview(save(value, null))).value);
  }
  async function completePayment(callbackUrl) {
    const incoming = callbackUrl ?? location.href();
    try {
      location.replace(callbackUri);
    } catch {
      return fail3("WALLET_PAYMENT_CALLBACK_INVALID", "The payment callback could not be cleared.");
    }
    const saved = pending();
    try {
      const url = new URL(incoming);
      if (incoming.length > 4096 || incoming.slice(0, incoming.indexOf("?")) !== callbackUri || url.origin + url.pathname !== callbackUri || url.username || url.password || url.hash || [...url.searchParams].length !== 3 || ["review", "state", "iss"].some((name) => url.searchParams.getAll(name).length !== 1) || url.searchParams.get("review") !== saved.value.review?.id || url.searchParams.get("state") !== saved.value.state || url.searchParams.get("iss") !== issuer) throw new Error();
    } catch {
      return fail3("WALLET_PAYMENT_CALLBACK_INVALID", "The callback does not match the original payment and app grant.");
    }
    const result = await live(saved.value).client.request({ requestTarget: reviewPath + "/" + saved.value.review.id });
    return status(receiveView(result, saved, true).value);
  }
  function receiveOperation(input, saved) {
    try {
      const operation = snapshot2(input), original = saved.value.operation;
      for (const name of ["id", "planId", "planCommitment", "commitment", "operationHash", "chainId", "entryPoint", "accountBindingId", "accountStateHash", "createdAt", "expiresAt"])
        if (operation[name] !== original[name]) mismatch();
      if (!equal(normalizeUserOperation(operation.operation), normalizeUserOperation(original.operation)) || !equal(operation.stepIndexes, original.stepIndexes) || operation.submission && !same3(operation.submission.commitment, saved.value.approval?.signedCommitment)) mismatch();
      const observation = operation.observation;
      if (observation && (!same3(observation.operationHash, original.operationHash) || observation.transactionHash !== void 0 && !hex32(observation.transactionHash))) mismatch();
      let result = operation.state === "pending" ? "pending" : operation.state === "confirming" ? "confirming" : "unknown";
      const receipt = observation?.receipt;
      const canonical = !!operation.submission && receipt?.canonical === true && hex32(receipt.blockHash) && hex32(receipt.transactionHash) && same3(receipt.transactionHash, observation?.transactionHash) && Number.isSafeInteger(receipt.confirmations) && receipt.confirmations > 0 && typeof receipt.blockNumber === "string" && /^(0|[1-9][0-9]{0,77})$/.test(receipt.blockNumber) && integer2(receipt.observedAt);
      if (operation.state === "confirmed" && observation?.state === "confirmed" && canonical && receipt?.status === "success" && observation.semantic?.status === "verified") result = "paid";
      if (operation.state === "reverted" && observation?.state === "reverted" && canonical && (receipt?.status === "reverted" || observation.semantic?.status === "failed")) result = "reverted";
      return save({ ...saved.value, status: result, ...observation ? { observation } : {} }, saved.encoded);
    } catch (error) {
      if (error instanceof RestClientError && ["WALLET_PAYMENT_STORAGE_UNAVAILABLE", "WALLET_PAYMENT_CHANGED"].includes(error.code)) throw error;
      return mismatch();
    }
  }
  async function submitPayment() {
    let saved = pending();
    const client = live(saved.value).client;
    if (!saved.value.approval || ["paid", "reverted", "cancelled"].includes(saved.value.status))
      fail3("WALLET_PAYMENT_NOT_APPROVED", "Retrieve fresh owner approval for this exact payment before submission.");
    if (!saved.value.submissionStarted && saved.value.operation.expiresAt <= now())
      fail3("WALLET_PAYMENT_EXPIRED", "This approval expired before submission. Preserve the payment for recovery.");
    saved = save({ ...saved.value, submissionStarted: true, status: "submitting" }, saved.encoded);
    try {
      const result = await client.smartAccounts().submitUserOperation(saved.value.operation.id, saved.value.approval.signature, saved.value.submissionKey);
      return status(receiveOperation(result, saved).value);
    } catch (error) {
      save({ ...saved.value, status: "unknown" }, saved.encoded);
      throw error;
    }
  }
  async function refreshPayment() {
    const saved = pending(), client = live(saved.value).client;
    try {
      if (saved.value.submissionStarted) return status(receiveOperation(await client.smartAccounts().userOperation(saved.value.operation.id), saved).value);
      if (!saved.value.review) return status((await requestReview(saved)).value);
      const value = await client.request({ requestTarget: reviewPath + "/" + saved.value.review.id });
      return status(receiveView(value, saved, true).value);
    } catch (error) {
      if (error instanceof RestClientError && ["WALLET_PAYMENT_MISMATCH", "WALLET_PAYMENT_CHANGED", "WALLET_PAYMENT_STORAGE_UNAVAILABLE"].includes(error.code)) throw error;
      return status(save({ ...saved.value, status: "unknown" }, saved.encoded).value);
    }
  }
  function pendingPayment() {
    const value = read()?.value;
    return value ? status(value) : null;
  }
  function clearPayment() {
    const saved = pending(), archivedAtMs = now(), signing = saved.value.operation.signing;
    if (!("ownerProfile" in signing)) mismatch();
    const terminal = ["paid", "reverted", "cancelled"].includes(saved.value.status);
    const unsignedWindowElapsed = saved.value.submissionStarted === false && !saved.value.approval && typeof signing.validUntil === "string" && /^[1-9][0-9]{0,14}$/.test(signing.validUntil) && BigInt(signing.validUntil) < 2n ** 48n && integer2(archivedAtMs) && BigInt(Math.floor(archivedAtMs / 1e3)) > BigInt(signing.validUntil);
    if (!terminal && !unsignedWindowElapsed)
      fail3("WALLET_PAYMENT_UNRESOLVED", "Keep this payment until its outcome is verified or its original approval window has elapsed without a saved approval or local submission.");
    const existing = raw(historyKey);
    try {
      const history = existing === null ? [] : JSON.parse(existing);
      if (!Array.isArray(history) || history.length >= 64) throw new Error();
      const receipt = {
        ...status(saved.value),
        ...!terminal ? { status: "unknown", archiveReason: "no-local-submission-recorded" } : {},
        issuer,
        audience,
        callbackUri,
        archivedAtMs,
        grantId: saved.value.grant.id,
        grantIncarnation: saved.value.grant.incarnation,
        planId: saved.value.plan.id,
        planCommitment: saved.value.plan.commitment,
        operationCommitment: saved.value.operation.commitment,
        reviewState: saved.value.state,
        reviewKey: saved.value.reviewKey,
        submissionKey: saved.value.submissionKey,
        validAfter: signing.validAfter,
        validUntil: signing.validUntil
      };
      const encoded = JSON.stringify([...history.filter((item) => item.operationId !== saved.value.operation.id), receipt]);
      if (new TextEncoder().encode(encoded).length > maximumBytes || raw() !== saved.encoded || raw(historyKey) !== existing) throw new Error();
      storage.setItem(historyKey, encoded);
      if (storage.getItem(historyKey) !== encoded || raw() !== saved.encoded) throw new Error();
      storage.removeItem(key);
      if (storage.getItem(key) !== null) throw new Error();
    } catch {
      fail3("WALLET_PAYMENT_STORAGE_UNAVAILABLE", "The original payment must be archived before clearing this tab\u2019s pending record.");
    }
  }
  return Object.freeze({ preparePayment, completePayment, submitPayment, refreshPayment, pendingPayment, clearPayment });
}

// src/rest/client/wallet.ts
var maximumBytes2 = 32 * 1024;
var requestFields = [
  "version",
  "issuer",
  "origin",
  "callbackUri",
  "audience",
  "appGeneration",
  "requestKey",
  "state",
  "codeChallenge",
  "nonce",
  "issuedAtMs",
  "expiresAtMs"
];
function fail4(code, message2) {
  throw new RestClientError(code, message2);
}
function invalid6() {
  return fail4("WALLET_RESPONSE_INVALID", "Center returned an invalid wallet connection response.");
}
function object2(value, required2, optional2 = []) {
  if (!value || typeof value !== "object" || Array.isArray(value)) invalid6();
  const fields2 = Object.keys(value);
  if (required2.some((key) => !fields2.includes(key)) || fields2.some((key) => !required2.includes(key) && !optional2.includes(key))) invalid6();
  return value;
}
function integer3(value) {
  return typeof value === "number" && Number.isSafeInteger(value) && value > 0;
}
function signature(value) {
  return typeof value === "string" && /^0x[0-9a-f]{130}$/.test(value);
}
function canonicalOrigin(value) {
  if (typeof value !== "string" || value.length > 512 || /[^\x21-\x7e]|[*\\%?#]/.test(value)) invalid6();
  let url;
  try {
    url = new URL(value);
  } catch {
    return invalid6();
  }
  if (url.origin !== value || url.username || url.password || url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname))) invalid6();
  return value;
}
function canonicalCallback(value, origin) {
  if (typeof value !== "string" || value.length > 2048 || /[^\x21-\x7e]|[*\\%?#]/.test(value)) invalid6();
  let url;
  try {
    url = new URL(value);
  } catch {
    return invalid6();
  }
  if (url.href !== value || url.origin !== origin || url.username || url.password || url.pathname.includes("//")) invalid6();
  return value;
}
function randomToken() {
  const bytes3 = crypto.getRandomValues(new Uint8Array(32));
  return btoa(String.fromCharCode(...bytes3)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function createCenterWalletClient(options) {
  let issuer, audience, callbackUri, origin;
  try {
    issuer = canonicalOrigin(options.issuer);
    audience = canonicalOrigin(options.audience);
    origin = canonicalOrigin(new URL(options.callbackUri).origin);
    callbackUri = canonicalCallback(options.callbackUri, origin);
  } catch {
    return fail4("WALLET_CONFIG_INVALID", "Use fixed canonical Center origins and an exact app callback URI.");
  }
  const now = options.now ?? Date.now, transport = options.fetch ?? globalThis.fetch;
  const timeoutMs = options.timeoutMs ?? 15e3;
  if (!integer3(timeoutMs) || timeoutMs > 6e4) fail4("WALLET_CONFIG_INVALID", "Use a wallet request timeout from 1 to 60000 milliseconds.");
  const location = options.location ?? {
    href: () => globalThis.location.href,
    replace: (url) => globalThis.history.replaceState(null, "", url)
  };
  const storageKey = "center.wallet.connection.v1:" + issuer + ":" + callbackUri;
  let disconnectVersion = 0;
  function clock() {
    const value = now();
    if (!integer3(value)) fail4("WALLET_CONFIG_INVALID", "The wallet connection clock is invalid.");
    return value;
  }
  function storage() {
    try {
      return options.storage ?? globalThis.sessionStorage;
    } catch {
      return fail4("WALLET_STORAGE_UNAVAILABLE", "This tab needs session storage to keep its wallet connection.");
    }
  }
  function raw() {
    try {
      return storage().getItem(storageKey);
    } catch {
      return fail4("WALLET_STORAGE_UNAVAILABLE", "This tab could not read its wallet connection.");
    }
  }
  function save(value, expected) {
    const encoded = JSON.stringify(value);
    if (raw() !== expected) fail4("WALLET_HANDOFF_CHANGED", "This tab changed its wallet connection. Resume the current connection.");
    try {
      if (new TextEncoder().encode(encoded).length > maximumBytes2) throw new Error();
      storage().setItem(storageKey, encoded);
      if (storage().getItem(storageKey) !== encoded) throw new Error();
    } catch {
      return fail4("WALLET_STORAGE_UNAVAILABLE", "This tab could not preserve its wallet connection.");
    }
    return encoded;
  }
  function checkRequest(value) {
    const r = object2(value, requestFields);
    if (r.version !== "center-wallet-handoff-request-v1" || r.issuer !== issuer || r.audience !== audience || r.origin !== origin || r.callbackUri !== callbackUri || !integer3(r.appGeneration) || !integer3(r.issuedAtMs) || !integer3(r.expiresAtMs) || r.expiresAtMs <= r.issuedAtMs || r.expiresAtMs - r.issuedAtMs > 3e5 || typeof r.requestKey !== "string" || !/^0x[0-9a-f]{40}$/.test(r.requestKey) || BigInt(r.requestKey) <= 1n || typeof r.nonce !== "string" || !/^0x[0-9a-f]{64}$/.test(r.nonce)) invalid6();
    try {
      validateWalletHandoffToken(r.state);
      validateWalletHandoffToken(r.codeChallenge);
    } catch {
      invalid6();
    }
    return r;
  }
  function checkIntent(value, request) {
    const intent = object2(value, ["id", "request", "state", "createdAtMs", "expiresAtMs"]);
    try {
      validateWalletHandoffToken(intent.id);
    } catch {
      invalid6();
    }
    const returned = checkRequest(intent.request);
    if (requestFields.some((field) => returned[field] !== request[field]) || intent.state !== "prepared" || !integer3(intent.createdAtMs) || intent.createdAtMs > clock() + 3e4 || intent.createdAtMs < request.issuedAtMs - 3e4 || intent.expiresAtMs !== request.expiresAtMs || intent.createdAtMs >= request.expiresAtMs) invalid6();
    return intent;
  }
  function checkGrant(value, request) {
    const g = object2(value, [
      "kind",
      "id",
      "incarnation",
      "accountId",
      "signerAddress",
      "scopes",
      "origin",
      "callbackUri",
      "audience",
      "appGeneration",
      "authorityEpoch",
      "sessionEpoch",
      "createdAt",
      "expiresAt",
      "revokedAt",
      "retainUntil"
    ]);
    const epoch = (value2) => typeof value2 === "string" && /^[1-9][0-9]{0,18}$/.test(value2) && BigInt(value2) <= 9223372036854775807n;
    if (g.kind !== "wallet-app" || typeof g.id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(g.id) || !epoch(g.incarnation) || !epoch(g.authorityEpoch) || !epoch(g.sessionEpoch) || typeof g.accountId !== "string" || !/^eip155:8453:0x[0-9a-f]{40}$/.test(g.accountId) || BigInt(g.accountId.slice(12)) <= 1n || g.signerAddress !== request.requestKey || g.signerAddress === g.accountId.slice(12) || !Array.isArray(g.scopes) || g.scopes.length !== 3 || g.scopes.join(",") !== "read,plan,relay" || g.origin !== origin || g.callbackUri !== callbackUri || g.audience !== audience || g.appGeneration !== request.appGeneration || !integer3(g.createdAt) || g.createdAt > Math.floor(clock() / 1e3) + 30 || !integer3(g.expiresAt) || g.expiresAt <= g.createdAt || g.expiresAt - g.createdAt > 3600 || g.revokedAt !== null || !integer3(g.retainUntil) || g.retainUntil !== g.expiresAt + 86400) invalid6();
    return g;
  }
  function read() {
    const encoded = raw();
    if (encoded === null) return null;
    try {
      if (new TextEncoder().encode(encoded).length > maximumBytes2) invalid6();
      const v = object2(JSON.parse(encoded), ["version", "key", "request", "signature"], ["verifier", "intent", "exchange", "grant"]);
      if (v.version !== "center-wallet-client-v1" || typeof v.key !== "string" || !/^0x[0-9a-f]{64}$/.test(v.key) || !signature(v.signature)) invalid6();
      const request = checkRequest(v.request);
      if (privateKeyToAccount3(v.key).address.toLowerCase() !== request.requestKey) invalid6();
      if (v.grant === void 0 || v.verifier !== void 0) {
        if (walletHandoffPkceChallenge(v.verifier) !== request.codeChallenge) invalid6();
      }
      if (v.intent !== void 0) checkIntent(v.intent, request);
      if (v.exchange !== void 0) {
        const exchange2 = object2(v.exchange, ["code"], ["signature"]);
        if (!v.intent || typeof v.verifier !== "string" || exchange2.signature !== void 0 && !signature(exchange2.signature)) invalid6();
        validateWalletHandoffToken(exchange2.code);
      }
      if (v.grant !== void 0) {
        if (!v.intent) invalid6();
        checkGrant(v.grant, request);
      }
      return { value: v, encoded };
    } catch {
      return fail4("WALLET_STORAGE_INVALID", "This tab has an invalid saved wallet connection. Disconnect it before starting again.");
    }
  }
  async function json(path, body) {
    const controller = new AbortController();
    const monotonicNow = () => globalThis.performance?.now() ?? Date.now(), deadlineAt = monotonicNow() + timeoutMs;
    const checkDeadline = () => {
      if (controller.signal.aborted || monotonicNow() >= deadlineAt) {
        controller.abort();
        fail4("WALLET_NETWORK_ERROR", "The wallet request timed out. Retry the pending connection.");
      }
    };
    let timer;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => {
        controller.abort();
        reject(new RestClientError("WALLET_NETWORK_ERROR", "The wallet request timed out. Retry the pending connection."));
      }, timeoutMs);
    });
    const execute = async () => {
      const response = await transport(issuer + path, {
        method: body === void 0 ? "GET" : "POST",
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        signal: controller.signal,
        headers: { accept: "application/json", "x-center-wallet-request": "1", ...body === void 0 ? {} : { "content-type": "application/json" } },
        ...body === void 0 ? {} : { body: JSON.stringify(body) }
      });
      if (controller.signal.aborted || monotonicNow() >= deadlineAt) {
        void response.body?.cancel().catch(() => {
        });
        checkDeadline();
      }
      if (response.redirected || response.url && response.url !== issuer + path) {
        void response.body?.cancel().catch(() => {
        });
        invalid6();
      }
      if (!response.ok) {
        void response.body?.cancel().catch(() => {
        });
        return fail4("WALLET_REQUEST_REJECTED", "Center rejected the wallet request. The pending connection has been preserved.");
      }
      if (!/^application\/json(?:\s*;|$)/i.test(response.headers.get("content-type") ?? "") || Number(response.headers.get("content-length")) > maximumBytes2 || !response.body) {
        void response.body?.cancel().catch(() => {
        });
        invalid6();
      }
      const reader = response.body.getReader(), chunks = [];
      const cancel = () => {
        void reader.cancel().catch(() => {
        });
      };
      controller.signal.addEventListener("abort", cancel, { once: true });
      let size3 = 0;
      try {
        while (true) {
          const part = await reader.read();
          checkDeadline();
          if (part.done) break;
          size3 += part.value.length;
          if (size3 > maximumBytes2) invalid6();
          chunks.push(part.value);
        }
        const bytes3 = new Uint8Array(size3);
        let offset = 0;
        for (const chunk of chunks) {
          bytes3.set(chunk, offset);
          offset += chunk.length;
        }
        let decoded;
        try {
          decoded = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes3));
        } catch {
          return invalid6();
        }
        checkDeadline();
        return decoded;
      } finally {
        controller.signal.removeEventListener("abort", cancel);
        cancel();
        reader.releaseLock();
      }
    };
    try {
      return await Promise.race([execute(), deadline]);
    } catch (error) {
      if (error instanceof RestClientError) throw error;
      return fail4("WALLET_NETWORK_ERROR", "The wallet request could not complete. Retry the pending connection.");
    } finally {
      clearTimeout(timer);
    }
  }
  async function prepared(intent) {
    const pending = read();
    if (!pending?.value.intent || pending.value.intent.id !== intent.id || pending.value.exchange || pending.value.grant)
      fail4("WALLET_HANDOFF_CHANGED", "This tab changed its wallet connection. Start again from the app.");
    const signature2 = await privateKeyToAccount3(pending.value.key).signTypedData(walletHandoffLaunchDocument({ request: intent.request, intentId: intent.id }));
    if (raw() !== pending.encoded) fail4("WALLET_HANDOFF_CHANGED", "This tab changed its wallet connection. Start again from the app.");
    return Object.freeze({
      intentId: intent.id,
      authorizationUrl: issuer + "/wallet?intent=" + intent.id,
      expiresAtMs: intent.expiresAtMs,
      launch() {
        if (raw() !== pending.encoded || intent.expiresAtMs <= clock())
          fail4("WALLET_HANDOFF_CHANGED", "This tab changed or expired its wallet connection. Start again from the app.");
        if (globalThis.location?.origin !== origin || !globalThis.document?.body)
          fail4("WALLET_LAUNCH_UNAVAILABLE", "Open the wallet connection from its original app tab.");
        const form = document.createElement("form");
        form.method = "POST";
        form.action = issuer + "/wallet/launch";
        form.target = "_self";
        form.hidden = true;
        for (const [name, value] of Object.entries({ intentId: intent.id, signature: signature2 })) {
          const input = document.createElement("input");
          input.type = "hidden";
          input.name = name;
          input.value = value;
          form.append(input);
        }
        try {
          document.body.append(form);
          HTMLFormElement.prototype.submit.call(form);
        } catch {
          fail4("WALLET_LAUNCH_UNAVAILABLE", "The wallet connection could not open. Try again from the app.");
        } finally {
          form.remove();
        }
      }
    });
  }
  function connection(saved) {
    const grant = saved.grant;
    const signer = privateKeyToAccount3(saved.key);
    const ensureActive = () => {
      const current = read()?.value;
      if (!current?.grant || current.key !== saved.key || current.grant.id !== grant.id || current.grant.incarnation !== grant.incarnation || current.grant.accountId !== grant.accountId || current.grant.expiresAt !== grant.expiresAt || grant.expiresAt <= Math.floor(clock() / 1e3))
        fail4("WALLET_CONNECTION_INACTIVE", "This wallet connection is disconnected, expired or replaced.");
    };
    const config = {
      audience,
      accountId: grant.accountId,
      grantId: grant.id,
      signer: {
        address: signer.address,
        signTypedData: async (document2) => {
          ensureActive();
          const signature2 = document2.primaryType === "CenterRequest" ? await signer.signTypedData(document2) : await signer.signTypedData(document2);
          ensureActive();
          return signature2;
        }
      },
      fetch: (input, init) => {
        ensureActive();
        return transport(input, init);
      },
      now: () => Math.floor(clock() / 1e3),
      timeoutMs
    };
    return Object.freeze({
      accountId: grant.accountId,
      address: grant.accountId.slice(12),
      chainId: 8453,
      expiresAt: grant.expiresAt,
      capabilities: Object.freeze(["read", "plan", "relay"]),
      client: new CenterClient(config)
    });
  }
  async function prepareConnection() {
    const startingVersion = disconnectVersion;
    let pending = read();
    if (pending?.value.exchange) fail4("WALLET_HANDOFF_PENDING", "Recover the pending exchange before starting another connection.");
    if (pending?.value.grant) fail4("WALLET_ALREADY_CONNECTED", "Disconnect the current wallet connection before replacing it.");
    if (pending && pending.value.request.expiresAtMs <= clock()) fail4("WALLET_HANDOFF_EXPIRED", "The connection request expired. Disconnect it before starting again.");
    if (pending?.value.intent) return prepared(pending.value.intent);
    if (!pending) {
      const config = object2(await json("/wallet/config?appOrigin=" + encodeURIComponent(origin)), ["version", "issuer", "audience", "rpId", "app"]);
      const app = object2(config.app, ["origin", "callbackUris", "generation"]);
      if (config.version !== "center-wallet-v1" || config.issuer !== issuer || config.audience !== audience || config.rpId !== new URL(issuer).hostname || app.origin !== origin || !integer3(app.generation) || !Array.isArray(app.callbackUris) || app.callbackUris.length > 4 || !app.callbackUris.includes(callbackUri) || new Set(app.callbackUris).size !== app.callbackUris.length) invalid6();
      app.callbackUris.forEach((uri) => canonicalCallback(uri, origin));
      const key = generatePrivateKey(), signer = privateKeyToAccount3(key), verifier = randomToken(), issuedAtMs = clock();
      const request = {
        version: "center-wallet-handoff-request-v1",
        issuer,
        audience,
        origin,
        callbackUri,
        appGeneration: app.generation,
        requestKey: signer.address.toLowerCase(),
        state: randomToken(),
        codeChallenge: walletHandoffPkceChallenge(verifier),
        nonce: toHex7(crypto.getRandomValues(new Uint8Array(32))),
        issuedAtMs,
        expiresAtMs: issuedAtMs + 3e5
      };
      const value = { version: "center-wallet-client-v1", key, verifier, request, signature: await signer.signTypedData(walletHandoffRequestDocument(request)) };
      if (startingVersion !== disconnectVersion) fail4("WALLET_HANDOFF_CHANGED", "This tab disconnected its wallet connection.");
      pending = { value, encoded: save(value, null) };
    }
    const intent = checkIntent(await json("/wallet/handoff/prepare", { request: pending.value.request, signature: pending.value.signature }), pending.value.request);
    save({ ...pending.value, intent }, pending.encoded);
    return prepared(intent);
  }
  async function exchange(pending) {
    let value = pending.value;
    if (!value.intent || !value.exchange || !value.verifier) fail4("WALLET_HANDOFF_MISSING", "There is no pending wallet exchange in this tab.");
    if (!value.exchange.signature) {
      const signature2 = await privateKeyToAccount3(value.key).signTypedData(walletHandoffExchangeDocument({
        request: value.request,
        intentId: value.intent.id,
        codeHash: walletHandoffCodeHash(value.exchange.code)
      }));
      value = { ...value, exchange: { code: value.exchange.code, signature: signature2 } };
      pending = { value, encoded: save(value, pending.encoded) };
    }
    const intent = value.intent, proof = value.exchange;
    const response = object2(await json("/wallet/handoff/exchange", {
      intentId: intent.id,
      request: value.request,
      code: proof.code,
      verifier: value.verifier,
      signature: proof.signature
    }), ["grant", "replayed"]);
    if (typeof response.replayed !== "boolean") invalid6();
    const grant = checkGrant(response.grant, value.request);
    if (grant.expiresAt <= Math.floor(clock() / 1e3)) invalid6();
    const connected = { version: value.version, key: value.key, request: value.request, signature: value.signature, intent, grant };
    save(connected, pending.encoded);
    return connection(connected);
  }
  async function completeConnection(callbackUrl) {
    const incoming = callbackUrl ?? location.href();
    try {
      location.replace(callbackUri);
    } catch {
      return fail4("WALLET_CALLBACK_INVALID", "The wallet callback could not be cleared safely.");
    }
    let pending = read();
    if (!pending?.value.intent || pending.value.grant) fail4("WALLET_CALLBACK_INVALID", "There is no matching wallet callback pending in this tab.");
    let code;
    try {
      if (typeof incoming !== "string" || incoming.length > 4096) throw new Error();
      const url = new URL(incoming), entries = [...url.searchParams];
      if (incoming.slice(0, incoming.indexOf("?")) !== callbackUri || url.origin + url.pathname !== callbackUri || url.username || url.password || url.hash || entries.length !== 3 || ["code", "state", "iss"].some((name) => url.searchParams.getAll(name).length !== 1) || url.searchParams.get("state") !== pending.value.request.state || url.searchParams.get("iss") !== issuer) throw new Error();
      code = validateWalletHandoffToken(url.searchParams.get("code"));
      if (pending.value.exchange && pending.value.exchange.code !== code) throw new Error();
    } catch {
      return fail4("WALLET_CALLBACK_INVALID", "The wallet callback does not match this tab and configured issuer.");
    }
    if (!pending.value.exchange) {
      const value = { ...pending.value, exchange: { code } };
      pending = { value, encoded: save(value, pending.encoded) };
    }
    return exchange(pending);
  }
  function restoreConnection() {
    const saved = read()?.value;
    return saved?.grant && saved.grant.expiresAt > Math.floor(clock() / 1e3) ? connection(saved) : null;
  }
  async function retryConnection() {
    const pending = read();
    if (pending?.value.grant) {
      const restored = restoreConnection();
      if (restored) return restored;
      fail4("WALLET_CONNECTION_EXPIRED", "The wallet connection expired. Disconnect it before starting again.");
    }
    if (!pending?.value.exchange) fail4("WALLET_HANDOFF_MISSING", "There is no pending wallet exchange in this tab.");
    return exchange(pending);
  }
  function disconnect() {
    disconnectVersion++;
    try {
      storage().removeItem(storageKey);
      if (storage().getItem(storageKey) !== null) throw new Error();
    } catch {
      fail4("WALLET_STORAGE_UNAVAILABLE", "This tab could not clear its wallet connection.");
    }
  }
  function payments() {
    return createCenterWalletPaymentClient({
      issuer,
      audience,
      callbackUri,
      location,
      now: clock,
      storage: { getItem: (key) => storage().getItem(key), setItem: (key, value) => storage().setItem(key, value), removeItem: (key) => storage().removeItem(key) },
      connection: () => {
        const saved = read()?.value;
        return saved?.grant && saved.grant.expiresAt > Math.floor(clock() / 1e3) ? { grant: structuredClone(saved.grant), client: connection(saved).client } : null;
      }
    });
  }
  return Object.freeze({ prepareConnection, completeConnection, retryConnection, restoreConnection, disconnect, payments });
}

// src/rest/client/index.ts
var RestClientError = class extends Error {
  constructor(code, message2, status) {
    super(message2);
    this.code = code;
    this.status = status;
    this.name = "RestClientError";
  }
  code;
  status;
};
function invalid7(message2) {
  throw new RestClientError("INVALID_INPUT", message2);
}
function clientAudience(value) {
  const audience = validateAudience(value);
  const url = new URL(audience);
  if (url.origin !== audience) return invalid7("Use the exact service origin as the audience");
  return audience;
}
function exactRequestUrl(audience, requestTarget) {
  if (requestTarget.length > 4096 || !/^\/(?!\/)[\x21-\x7e]*$/.test(requestTarget) || /[#\\]/.test(requestTarget) || /%(?![0-9a-fA-F]{2})/.test(requestTarget)) {
    return invalid7("Use an exact encoded path and query without a fragment");
  }
  const url = `${clientAudience(audience)}${requestTarget}`;
  const parsed = new URL(url);
  if (parsed.origin !== audience || `${parsed.pathname}${parsed.search}` !== requestTarget) {
    return invalid7("The request target would be normalized by the HTTP client");
  }
  return url;
}
function documentBytes(options) {
  if (options.json !== void 0 && options.body !== void 0) return invalid7("Supply JSON or raw bytes, not both");
  const method = options.method ?? "GET";
  if (!/^(GET|HEAD|POST|PUT|PATCH|DELETE|OPTIONS)$/.test(method)) return invalid7("Use an uppercase HTTP method");
  let body;
  if (options.json !== void 0) {
    const encoded = JSON.stringify(options.json);
    if (encoded === void 0) return invalid7("The JSON body cannot be encoded");
    body = new TextEncoder().encode(encoded);
  } else body = options.body?.slice() ?? new Uint8Array();
  if (body.byteLength > 2 * 1024 * 1024) return invalid7("Request body exceeds the client limit");
  if ((method === "GET" || method === "HEAD") && body.length) return invalid7("GET and HEAD requests cannot carry a body");
  const contentType = options.contentType ?? (options.json === void 0 ? "" : "application/json");
  if (contentType.length > 256 || /[\r\n\0]/.test(contentType) || new Headers({ "content-type": contentType }).get("content-type") !== contentType) {
    return invalid7("Invalid exact content type");
  }
  return { body, contentType, method };
}
async function signBytes(config, options, bytes3) {
  const audience = clientAudience(config.audience);
  const url = exactRequestUrl(audience, options.requestTarget);
  parseAccountId(config.accountId);
  if (!isAddress9(config.signer.address)) return invalid7("Invalid signer address");
  const issuedAt = config.now?.() ?? Math.floor(Date.now() / 1e3);
  if (!Number.isSafeInteger(issuedAt) || issuedAt < 1) return invalid7("Invalid client clock");
  const nonce = options.nonce ?? newRequestNonce();
  if (!/^0x[0-9a-f]{64}$/.test(nonce)) return invalid7("Invalid request nonce");
  const idempotencyKey = options.idempotencyKey ?? "";
  if (idempotencyKey && !/^[A-Za-z0-9._:-]{1,128}$/.test(idempotencyKey)) return invalid7("Invalid idempotency key");
  const grantId = config.grantId ?? "";
  if (grantId && !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(grantId)) return invalid7("Invalid bot grant ID");
  const claims2 = {
    accountId: config.accountId,
    signer: getAddress7(config.signer.address),
    grantId,
    method: bytes3.method,
    requestTarget: options.requestTarget,
    contentType: bytes3.contentType,
    bodyHash: keccak2569(bytes3.body),
    issuedAt,
    expiresAt: issuedAt + 300,
    nonce,
    idempotencyKey
  };
  const signature2 = await config.signer.signTypedData(buildRequestTypedData(audience, claims2));
  const headers = new Headers({
    [REST_AUTH_HEADERS.account]: claims2.accountId,
    [REST_AUTH_HEADERS.signer]: claims2.signer,
    [REST_AUTH_HEADERS.issuedAt]: String(issuedAt),
    [REST_AUTH_HEADERS.expiresAt]: String(claims2.expiresAt),
    [REST_AUTH_HEADERS.nonce]: nonce,
    [REST_AUTH_HEADERS.signature]: signature2,
    accept: "application/json"
  });
  if (bytes3.contentType) headers.set("content-type", bytes3.contentType);
  if (grantId) headers.set(REST_AUTH_HEADERS.grant, grantId);
  if (idempotencyKey) headers.set(REST_AUTH_HEADERS.idempotencyKey, idempotencyKey);
  return { url, method: bytes3.method, body: bytes3.body, headers, claims: claims2 };
}
async function prepareSignedRequest(config, options) {
  return signBytes(config, options, documentBytes(options));
}
async function boundedJson(response, maximum) {
  const declared = response.headers.get("content-length");
  if (declared && Number(declared) > maximum) {
    void response.body?.cancel().catch(() => void 0);
    throw new RestClientError("RESPONSE_TOO_LARGE", "Response exceeds the client limit");
  }
  if (!response.headers.get("content-type")?.toLowerCase().includes("json")) {
    void response.body?.cancel().catch(() => void 0);
    throw new RestClientError("INVALID_RESPONSE", "Expected a JSON response", response.status);
  }
  const reader = response.body?.getReader();
  if (!reader) throw new RestClientError("INVALID_RESPONSE", "The response body is missing", response.status);
  const chunks = [];
  let total = 0;
  try {
    for (; ; ) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maximum) throw new RestClientError("RESPONSE_TOO_LARGE", "Response exceeds the client limit");
      chunks.push(value);
    }
  } catch (error) {
    void reader.cancel().catch(() => void 0);
    throw error;
  } finally {
    reader.releaseLock();
  }
  const bytes3 = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes3.set(chunk, offset);
    offset += chunk.length;
  }
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes3));
  } catch {
    throw new RestClientError("INVALID_RESPONSE", "The response is not valid JSON", response.status);
  }
}
async function readPublicRestJson(audience, requestTarget, transport = fetch) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15e3);
  try {
    const response = await transport(exactRequestUrl(clientAudience(audience), requestTarget), {
      headers: { accept: "application/json" },
      redirect: "error",
      credentials: "omit",
      cache: "no-store",
      signal: controller.signal
    });
    const result = await boundedJson(response, 2 * 1024 * 1024);
    if (!response.ok) throw new RestClientError("DISCOVERY_UNAVAILABLE", "This host has not enabled the requested wallet capability.", response.status);
    return result;
  } catch (error) {
    if (error instanceof RestClientError) throw error;
    throw new RestClientError("DISCOVERY_UNAVAILABLE", "Wallet discovery could not be loaded.");
  } finally {
    clearTimeout(timer);
  }
}
var SignedRestClient2 = class {
  config;
  constructor(config) {
    this.config = { ...config, audience: clientAudience(config.audience) };
    parseAccountId(config.accountId);
  }
  async request(options) {
    const retries = options.retries ?? 0;
    const timeoutMs = this.config.timeoutMs ?? 15e3;
    const maxBytes = this.config.maxResponseBytes ?? 2 * 1024 * 1024;
    if (!Number.isSafeInteger(retries) || retries < 0 || retries > 2 || options.nonce !== void 0 && retries > 0) return invalid7("Use at most two retries; proof-bound requests cannot auto-retry");
    if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 6e4 || !Number.isSafeInteger(maxBytes) || maxBytes < 1 || maxBytes > 5 * 1024 * 1024) return invalid7("Invalid client limits");
    const bytes3 = documentBytes(options);
    if (retries && !["GET", "HEAD"].includes(bytes3.method) && !options.idempotencyKey) return invalid7("Mutation retries require an idempotency key");
    for (let attempt = 0; ; attempt++) {
      let prepared;
      try {
        prepared = await signBytes(this.config, options, bytes3);
      } catch (error) {
        const failure = error instanceof RestClientError ? new RestClientError(error.code, error.message, error.status) : new Error(error instanceof Error ? error.message : "The API request could not be signed.");
        if (error && typeof error === "object") {
          if ("name" in error && typeof error.name === "string") failure.name = error.name;
          if ("code" in error && ["number", "string"].includes(typeof error.code))
            Object.defineProperty(failure, "code", { value: error.code, enumerable: true });
        }
        Object.defineProperty(failure, "requestNotSent", { value: attempt === 0, enumerable: true });
        throw failure;
      }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const response = await (this.config.fetch ?? fetch)(prepared.url, {
          method: prepared.method,
          headers: prepared.headers,
          ...prepared.body.length ? { body: prepared.body } : {},
          redirect: "error",
          credentials: "omit",
          cache: "no-store",
          signal: controller.signal
        });
        if ([408, 429, 502, 503, 504].includes(response.status) && attempt < retries) {
          await response.body?.cancel();
          continue;
        }
        const result = await boundedJson(response, maxBytes);
        if (!response.ok) {
          const error = result && typeof result === "object" && "error" in result ? result.error : result;
          const code = error && typeof error === "object" && "code" in error && typeof error.code === "string" && /^[A-Z0-9_]{1,80}$/.test(error.code) ? error.code : "REQUEST_FAILED";
          throw new RestClientError(code, `The service rejected this request (${response.status}, ${code})`, response.status);
        }
        return result;
      } catch (error) {
        if (error instanceof RestClientError) throw error;
        if (attempt >= retries) throw new RestClientError(controller.signal.aborted ? "TIMEOUT" : "NETWORK_ERROR", controller.signal.aborted ? "The request timed out; its outcome may be unknown" : "The request did not complete; its outcome may be unknown");
      } finally {
        clearTimeout(timer);
      }
    }
  }
};
async function createBotRegistration(audience, proof, signer) {
  if (!isCanonicalGrantScopes(proof.scopes)) return invalid7("Choose exactly read, read + plan, or read + plan + relay in that order");
  if (proof.botAddress.toLowerCase() !== signer.address.toLowerCase()) return invalid7("The bot signer must match the registration address");
  const proofSignature = await signer.signTypedData(buildBotProofTypedData(audience, proof));
  return parseBotRegistration({
    format: "juicebox-center-bot-registration-v1",
    audience: clientAudience(audience),
    accountId: proof.accountId,
    ownerRequestNonce: proof.ownerRequestNonce,
    registration: { botAddress: proof.botAddress, scopes: [...proof.scopes], expiresAt: proof.expiresAt, label: proof.label, proofSignature }
  });
}
function parseBotRegistration(value) {
  const object3 = (item) => !!item && typeof item === "object" && !Array.isArray(item);
  if (!object3(value) || Object.keys(value).some((key) => !["format", "audience", "accountId", "ownerRequestNonce", "registration"].includes(key)) || value.format !== "juicebox-center-bot-registration-v1" || typeof value.audience !== "string" || typeof value.accountId !== "string" || typeof value.ownerRequestNonce !== "string" || !/^0x[0-9a-f]{64}$/.test(value.ownerRequestNonce) || !object3(value.registration)) return invalid7("Invalid public bot registration document");
  const r = value.registration;
  if (Object.keys(r).some((key) => !["botAddress", "scopes", "expiresAt", "label", "proofSignature"].includes(key)) || typeof r.botAddress !== "string" || !isAddress9(r.botAddress) || !isCanonicalGrantScopes(r.scopes) || !Number.isSafeInteger(r.expiresAt) || Number(r.expiresAt) < 1 || typeof r.label !== "string" || new TextEncoder().encode(r.label).length > 120 || typeof r.proofSignature !== "string" || !/^0x[0-9a-fA-F]{130}$/.test(r.proofSignature)) return invalid7("Invalid public bot proof fields");
  parseAccountId(value.accountId);
  return {
    format: "juicebox-center-bot-registration-v1",
    audience: clientAudience(value.audience),
    accountId: value.accountId,
    ownerRequestNonce: value.ownerRequestNonce,
    registration: { botAddress: getAddress7(r.botAddress), scopes: [...r.scopes], expiresAt: Number(r.expiresAt), label: r.label, proofSignature: r.proofSignature }
  };
}
export {
  CenterClient,
  REST_AUTH_HEADERS,
  RestClientError,
  SignedRestClient2 as SignedRestClient,
  SmartAccountClient,
  accountIdFor,
  assertReviewedOperation,
  assertWalletIdentity,
  buildSponsorshipApprovalTypedData,
  buildTransactionApprovalTypedData,
  clientAudience,
  connectionForBot,
  createBotRegistration,
  createCenterWalletClient,
  exactRequestUrl,
  isCanonicalGrantScopes,
  newRequestNonce,
  ownerOperationSignature,
  ownerOperationSigning,
  packOwnerSignatures,
  parseBotRegistration,
  parseConnection,
  prepareSignedRequest,
  readPublicRestJson,
  sessionActionPlanInput,
  signSessionUserOperation,
  signWalletTypedData,
  smartBindingDocument,
  smartRequestKey,
  sponsorshipSubmissionHash,
  userOperationMaximumCost,
  verifyWalletCreation,
  walletTypedDataDocument
};
