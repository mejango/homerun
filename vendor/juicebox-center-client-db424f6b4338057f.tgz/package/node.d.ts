import { CenterClient, ClientOptions } from './index.js';
export declare function connect(filename: string, options?: Pick<ClientOptions, 'fetch' | 'timeoutMs' | 'now'>): Promise<CenterClient>;
